=== LeyMish AI Shopping Readiness Pro ===
Contributors: leymishlabs
Tags: woocommerce, product feed, gtin, chatgpt, llms.txt
Requires at least: 6.4
Tested up to: 7.1
Requires PHP: 7.4
Stable tag: 1.3.0
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Pro add-on for LeyMish AI Shopping Readiness: bulk GTIN/brand/MPN editor, OpenAI and Google feeds, llms.txt, weekly re-audit email.

== Description ==

Needs the free LeyMish AI Shopping Readiness plugin and a license key from your Gumroad purchase.

* Bulk editor for GTIN, brand and MPN (variations included; GTIN check digits verified).
* OpenAI product feed (JSONL) and Google Merchant Center feed (TSV) at /lasr-feed/openai.jsonl and /lasr-feed/google.tsv.
* Generated /llms.txt with your store summary, categories, policies and feed links.
* Weekly re-audit email to the site admin, and score history.

= External service =

To check your license, the add-on sends your license key and the product ID to Gumroad's license API (https://api.gumroad.com/v2/licenses/verify) when you activate it and once a week. Nothing else is sent. Gumroad terms: https://gumroad.com/terms and privacy policy: https://gumroad.com/privacy

**Pro AI (optional, off until you tick the consent box on WooCommerce → AI fixes).** When you click "Suggest" on a
product, the add-on sends that product's name, descriptions, attributes, category names and, for alt text, its main
image URL, plus your store URL and your Pro AI licence key if you have one, to the LeyMish AI service, which asks an AI
model for a suggestion. No customer, order or personal data is sent. The service keeps counters (fixes used per store,
hashed), not your product text, and the AI provider doesn't train on it. Nothing changes in your store until you
review the suggestion and click Apply. Pro AI never creates GTINs, EANs, UPCs, MPNs or ISBNs.

== Installation ==

1. Install and activate WooCommerce and the free LeyMish AI Shopping Readiness plugin.
2. Upload this zip under Plugins → Add New → Upload Plugin, and activate it.
3. Paste your license key in WooCommerce → AI Readiness Pro.

== Changelog ==

= 1.3.0 =
* Impact tab (with the free plugin 1.1.0+): "Work done by Pro" counts the products you gave a GTIN, MPN or brand in the bulk editor and the AI suggestions you applied, shows AI fixes used and left, and offers a one-page before/after report (HTML: open, print or save as PDF). Counts are stored on your site only.

= 1.2.1 =
* One key for everything: an active Pro AI or Pro AI Agency membership key also unlocks every Pro feature, and the AI fixes screen uses it automatically.
* The Pro AI upgrade link goes straight to checkout.
* A cancelled membership stays active until the paid period ends (only an ended or failed subscription expires the key).

= 1.2.0 =
* New: WooCommerce → AI fixes. One-click suggestions for missing attributes (only ones stated in your product text), a clearer spec-first description, a Google product category from Google's own taxonomy, and image alt text. You review every suggestion and pick what to keep; nothing is saved until you click Apply. 20 free fixes per store; more with a Pro AI licence.
* Never creates product identifiers (GTIN, EAN, UPC, MPN, ISBN); identifier-shaped values are dropped from every suggestion.

= 1.1.0 =
* Agency licence support: one key for up to 10 stores (a separate Gumroad product).
* A key activated far more often than its store count allows is refused, with a message to reply to the Gumroad receipt. Reinstalls on the same store are allowed for.

= 1.0.0 =
* First release.
