<?php
/**
 * Forget the connection when the plugin is deleted. (Also revoke the key in WooCommerce → Settings → Advanced →
 * REST API; disconnecting first deletes our copy of it.)
 *
 * @package LeyMish_Store_Team
 */

if ( ! defined( 'WP_UNINSTALL_PLUGIN' ) ) {
	exit;
}

delete_option( 'lst_connection' );
delete_transient( 'lst_waiting_count' ); // the approvals menu badge (0.3.0)
