<?php
/**
 * The approvals inbox: WooCommerce → Store Team → Approvals (P-023 §1).
 *
 * Until 0.2.0 the owner approved store changes from links in a daily email. Mick asked for the opposite. So:
 *
 *   - every decision happens on this page, behind `manage_woocommerce` and a nonce;
 *   - the browser never sees the site token — the PHP here passes it to the LeyMish service server-side;
 *   - there is no public decision URL at all. The old signed links are gone from the service too.
 *
 * @package LeyMish_Store_Team
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Approvals page, menu badge and the AJAX endpoints behind them.
 */
class LST_Approvals {

	const SLUG       = 'leymish-store-team-approvals';
	const COUNT_KEY  = 'lst_waiting_count';
	const COUNT_TTL  = 300; // Five minutes: fresh enough for a badge, cheap enough for every admin page load.

	/**
	 * Hooks.
	 */
	public static function init() {
		add_action( 'admin_menu', array( __CLASS__, 'menu' ), 62 );
		add_action( 'admin_enqueue_scripts', array( __CLASS__, 'assets' ) );
		add_action( 'admin_notices', array( __CLASS__, 'notice' ) );
		add_action( 'wp_ajax_lst_approvals', array( __CLASS__, 'ajax_list' ) );
		add_action( 'wp_ajax_lst_approvals_decide', array( __CLASS__, 'ajax_decide' ) );
	}

	/**
	 * WooCommerce → Store Team → Approvals, with the waiting count in the menu.
	 */
	public static function menu() {
		$n     = self::waiting_count();
		$label = __( 'Approvals', 'leymish-store-team' );
		if ( $n > 0 ) {
			$label .= ' <span class="update-plugins count-' . (int) $n . '"><span class="plugin-count">' . esc_html( number_format_i18n( $n ) ) . '</span></span>';
		}
		add_submenu_page( 'woocommerce', __( 'Store Team approvals', 'leymish-store-team' ), $label, 'manage_woocommerce', self::SLUG, array( __CLASS__, 'render' ) );
	}

	/**
	 * How many changes are waiting, cached so the badge doesn't call out on every page load.
	 *
	 * @param bool $fresh Skip the cache.
	 * @return int
	 */
	public static function waiting_count( $fresh = false ) {
		if ( ! $fresh ) {
			$cached = get_transient( self::COUNT_KEY );
			if ( false !== $cached ) {
				return (int) $cached;
			}
		}
		$c = LST_Admin::connection();
		if ( ! $c ) {
			return 0;
		}
		$r = LST_Admin::call( 'approvals/count', array(), $c['site_token'] );
		$n = 200 === $r['status'] ? (int) ( $r['data']['waiting'] ?? 0 ) : 0;
		set_transient( self::COUNT_KEY, $n, self::COUNT_TTL );
		return $n;
	}

	/**
	 * Forget the cached count after a decision, so the badge matches the page.
	 */
	public static function forget_count() {
		delete_transient( self::COUNT_KEY );
	}

	/**
	 * Our own screens only — never a site-wide nag. (P-023: "not site-wide".)
	 */
	public static function notice() {
		$screen = function_exists( 'get_current_screen' ) ? get_current_screen() : null;
		if ( ! $screen || false === strpos( (string) $screen->id, 'leymish-store-team' ) || false !== strpos( (string) $screen->id, self::SLUG ) ) {
			return;
		}
		if ( ! current_user_can( 'manage_woocommerce' ) ) {
			return;
		}
		$n = self::waiting_count();
		if ( $n < 1 ) {
			return;
		}
		printf(
			'<div class="notice notice-info"><p>%s <a href="%s">%s</a></p></div>',
			esc_html( sprintf(
				/* translators: %d: number of changes waiting for approval. */
				_n( '%d change is waiting for your approval.', '%d changes are waiting for your approval.', $n, 'leymish-store-team' ),
				$n
			) ),
			esc_url( admin_url( 'admin.php?page=' . self::SLUG ) ),
			esc_html__( 'Review them', 'leymish-store-team' )
		);
	}

	/**
	 * CSS and JS on the approvals page only.
	 *
	 * @param string $hook Page hook.
	 */
	public static function assets( $hook ) {
		if ( false === strpos( (string) $hook, self::SLUG ) ) {
			return;
		}
		wp_enqueue_style( 'lst-admin', plugins_url( 'assets/team.css', LST_FILE ), array(), LST_VERSION );
		if ( ! LST_Admin::connection() ) {
			return; // render() prints the whole page itself in that case; there is nothing to fetch.
		}
		wp_enqueue_script( 'lst-approvals', plugins_url( 'assets/approvals.js', LST_FILE ), array(), LST_VERSION, true );
		wp_localize_script( 'lst-approvals', 'LST_APPROVALS', array(
			'ajax'      => admin_url( 'admin-ajax.php' ),
			'nonce'     => wp_create_nonce( 'lst_approvals' ),
			'connected' => (bool) LST_Admin::connection(),
			'i18n'      => array(
				'now'        => __( 'Now', 'leymish-store-team' ),
				'proposed'   => __( 'Proposed', 'leymish-store-team' ),
				'approve'    => __( 'Approve', 'leymish-store-team' ),
				'reject'     => __( 'Reject', 'leymish-store-team' ),
				'edit'       => __( 'Edit then approve', 'leymish-store-team' ),
				'save'       => __( 'Save and approve', 'leymish-store-team' ),
				'cancel'     => __( 'Cancel', 'leymish-store-team' ),
				'selectAll'  => __( 'Select all', 'leymish-store-team' ),
				'bulkYes'    => __( 'Approve selected', 'leymish-store-team' ),
				'bulkNo'     => __( 'Reject selected', 'leymish-store-team' ),
				'empty'      => __( 'Nothing is waiting for you.', 'leymish-store-team' ),
				'loading'    => __( 'Loading…', 'leymish-store-team' ),
				'applied'    => __( 'Approved and applied to your store.', 'leymish-store-team' ),
				'queued'     => __( 'Approved. It will be applied on the next run.', 'leymish-store-team' ),
				'rejected'   => __( 'Rejected. Nothing changed.', 'leymish-store-team' ),
				'failed'     => __( 'That did not save.', 'leymish-store-team' ),
				'offline'    => __( 'Could not reach the server. Try again in a minute.', 'leymish-store-team' ),
				'notConn'    => __( 'Connect your store on the Store Team page before you can approve anything.', 'leymish-store-team' ),
				'dropped'    => __( 'We left these out', 'leymish-store-team' ),
				'history'    => __( 'Decisions you have already made', 'leymish-store-team' ),
				'waiting'    => __( 'Waiting for you', 'leymish-store-team' ),
				'chooseSome' => __( 'Tick at least one change first.', 'leymish-store-team' ),
			),
		) );
	}

	/**
	 * The page shell. Everything in it is drawn by approvals.js from the AJAX call, so the markup here holds no
	 * store data and the page is cacheable and translatable.
	 */
	public static function render() {
		if ( ! current_user_can( 'manage_woocommerce' ) ) {
			return;
		}
		echo '<div class="wrap lst-wrap"><h1>' . esc_html__( 'Store Team approvals', 'leymish-store-team' ) . '</h1>';
		echo '<p class="description">' . esc_html__( 'Nothing below has happened yet. Approve, edit then approve, or reject — your store only changes when you say so.', 'leymish-store-team' ) . '</p>';
		// An unconnected store has nothing to fetch, so say so here rather than shipping a "Loading…" that a
		// failed request would leave on screen forever. The script only runs when there is something to load.
		if ( ! LST_Admin::connection() ) {
			echo '<div class="notice notice-warning inline"><p>';
			printf(
				/* translators: %s: link to the Store Team page. */
				esc_html__( 'This store is not connected yet, so there is nothing waiting. %s and your team will start proposing changes here.', 'leymish-store-team' ),
				'<a href="' . esc_url( admin_url( 'admin.php?page=' . LST_Admin::SLUG ) ) . '">' . esc_html__( 'Connect it on the Store Team page', 'leymish-store-team' ) . '</a>'
			);
			echo '</p></div></div>';
			return;
		}
		echo '<div id="lst-approvals"><p>' . esc_html__( 'Loading…', 'leymish-store-team' ) . '</p></div></div>';
	}

	/**
	 * Capability + nonce + a live connection, or an error response. Every AJAX entry point starts here.
	 *
	 * @return array|null The connection, or null once an error has been sent.
	 */
	private static function guard() {
		check_ajax_referer( 'lst_approvals' );
		if ( ! current_user_can( 'manage_woocommerce' ) ) {
			wp_send_json_error( array( 'message' => __( 'You do not have permission to do that.', 'leymish-store-team' ) ), 403 );
			return null;
		}
		$c = LST_Admin::connection();
		if ( ! $c ) {
			wp_send_json_error( array( 'message' => __( 'This store is not connected.', 'leymish-store-team' ) ), 400 );
			return null;
		}
		return $c;
	}

	/**
	 * Everything waiting, plus the decisions already made.
	 */
	public static function ajax_list() {
		$c = self::guard();
		if ( ! $c ) {
			return;
		}
		$r = LST_Admin::call( 'approvals', array(), $c['site_token'] );
		if ( 200 !== $r['status'] ) {
			wp_send_json_error( array( 'message' => __( 'Could not load your approvals just now.', 'leymish-store-team' ) ), 502 );
		}
		set_transient( self::COUNT_KEY, count( (array) ( $r['data']['waiting'] ?? array() ) ), self::COUNT_TTL );
		wp_send_json_success( $r['data'] );
	}

	/**
	 * Approve, reject, edit-then-approve, or the same in bulk.
	 *
	 * The edit is passed through as the owner typed it; the service re-runs the claims guard, the attribute
	 * vocabulary and the field whitelist over it, because an edit is still our write to their store.
	 */
	public static function ajax_decide() {
		$c = self::guard();
		if ( ! $c ) {
			return;
		}
		$decision = isset( $_POST['decision'] ) && 'approve' === sanitize_key( wp_unslash( $_POST['decision'] ) ) ? 'approve' : 'reject';
		$body     = array( 'decision' => $decision );

		if ( isset( $_POST['ids'] ) && is_array( $_POST['ids'] ) ) {
			$ids = array_values( array_filter( array_map( 'absint', wp_unslash( $_POST['ids'] ) ) ) );
			if ( ! $ids ) {
				wp_send_json_error( array( 'message' => __( 'Tick at least one change first.', 'leymish-store-team' ) ), 400 );
			}
			$body['ids'] = array_slice( $ids, 0, 50 );
		} else {
			$id = isset( $_POST['id'] ) ? absint( $_POST['id'] ) : 0;
			if ( ! $id ) {
				wp_send_json_error( array( 'message' => __( 'That change no longer exists.', 'leymish-store-team' ) ), 400 );
			}
			$body['id'] = $id;
			$edit       = self::read_edit();
			if ( $edit ) {
				$body['edit'] = $edit;
			}
		}

		$r = LST_Admin::call( 'approvals/decide', $body, $c['site_token'] );
		self::forget_count();
		if ( 200 !== $r['status'] ) {
			$message = isset( $r['data']['error'] ) ? (string) $r['data']['error'] : __( 'That did not save.', 'leymish-store-team' );
			wp_send_json_error( array( 'message' => $message ), 400 );
		}
		wp_send_json_success( $r['data'] );
	}

	/**
	 * The owner's edit, if they made one: either one text value or a list of attributes.
	 *
	 * Unslashed and stripped of tags here; the service validates the content. `wp_kses` is not used because
	 * none of these fields may contain markup at all — an attribute value and an alt text are plain text.
	 *
	 * @return array|null
	 */
	private static function read_edit() {
		// phpcs:disable WordPress.Security.NonceVerification.Missing -- guard() ran check_ajax_referer already.
		if ( isset( $_POST['edit_value'] ) ) {
			$v = trim( wp_strip_all_tags( wp_unslash( $_POST['edit_value'] ) ) ); // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- stripped above; the service validates.
			return '' === $v ? null : array( 'value' => $v );
		}
		if ( isset( $_POST['edit_attributes'] ) && is_array( $_POST['edit_attributes'] ) ) {
			$out = array();
			foreach ( wp_unslash( $_POST['edit_attributes'] ) as $row ) { // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- each field sanitised below.
				if ( ! is_array( $row ) ) {
					continue;
				}
				$name  = trim( wp_strip_all_tags( (string) ( $row['name'] ?? '' ) ) );
				$value = trim( wp_strip_all_tags( (string) ( $row['value'] ?? '' ) ) );
				if ( '' !== $name && '' !== $value ) {
					$out[] = array( 'name' => $name, 'value' => $value );
				}
			}
			return $out ? array( 'attributes' => array_slice( $out, 0, 6 ) ) : null;
		}
		// phpcs:enable WordPress.Security.NonceVerification.Missing
		return null;
	}
}
