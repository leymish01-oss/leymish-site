=== LeyMish Store Team ===
Contributors: leymish
Tags: woocommerce, ai, product data, catalog, automation
Requires at least: 6.4
Tested up to: 7.1
Requires PHP: 7.4
Stable tag: 0.3.0
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

An AI team that keeps your WooCommerce product data in shape and asks before every change. Beta.

== Description ==

Store Team reads your WooCommerce catalogue every week, finds what shoppers and AI shopping assistants can't see
(missing attributes, image alt text, product categories, thin descriptions) and proposes the exact fix. You see the
before and after; nothing changes until you approve. Every change can be undone.

It never touches prices, payments, shipping, tax, refunds, themes, plugins, users, and it never deletes anything.

Founding beta: 5 WooCommerce stores get it free for 30 days, then $49/month only if they choose to continue.
Details: https://www.leymish.com/woocommerce/store-team/

== Changelog ==

= 0.3.0 =
* Approvals now live in your own admin: WooCommerce -> Store Team -> Approvals, with a count in the menu.
* Each waiting change shows what it is now and what we propose. Approve, edit then approve, reject, or decide several at once. Past decisions are listed underneath.
* The daily email is a notice only. It says how many changes are waiting and links to your dashboard; it no longer carries approve or reject links, and nothing in an email can change your store.
* Proposed product attributes now follow a fixed list (Product type, Size, Key ingredients, Skin type, Scent, Format, Material, Colour), at most 6 per product, at most 60 characters each, facts from your own product page only, and never a claim about what a product does for someone.
* Edits you make are re-checked the same way the original suggestion was.

= 0.2.0 =
* Proposals show the exact before and after; Revert on Results; the mode (ask before every change) in Settings; the founding beta button; a clean uninstall.
