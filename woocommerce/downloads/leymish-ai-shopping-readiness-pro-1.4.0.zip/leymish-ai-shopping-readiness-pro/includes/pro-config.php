<?php
/**
 * Build-time settings. build.py writes the Gumroad product ID here from pro-config.json.
 *
 * @package LeyMish_AI_Shopping_Readiness_Pro
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! defined( 'LASR_PRO_GUMROAD_PRODUCT_ID' ) ) {
	define( 'LASR_PRO_GUMROAD_PRODUCT_ID', 'a9h7HfYtbwzQv6xxDhSAdQ==' );
}

// Agency licence (10 stores): a separate Gumroad product. Empty until that product exists.
if ( ! defined( 'LASR_PRO_GUMROAD_AGENCY_PRODUCT_ID' ) ) {
	define( 'LASR_PRO_GUMROAD_AGENCY_PRODUCT_ID', '' );
}

// Pro AI memberships (P-015): an active Pro AI or Pro AI Agency key also unlocks Pro. Empty until build.py fills them.
if ( ! defined( 'LASR_PRO_GUMROAD_PROAI_PRODUCT_ID' ) ) {
	define( 'LASR_PRO_GUMROAD_PROAI_PRODUCT_ID', '108DoU17OVIZjP7a0leKHQ==' );
}
if ( ! defined( 'LASR_PRO_GUMROAD_PROAI_AGENCY_PRODUCT_ID' ) ) {
	define( 'LASR_PRO_GUMROAD_PROAI_AGENCY_PRODUCT_ID', 'MvWhnOIQ61X07f0ViiuFDA==' );
}

// Pro AI proxy (LeyMish AI, workers.dev). Empty until the proxy is deployed; the AI fixes screen says so.
if ( ! defined( 'LASR_PRO_AI_ENDPOINT' ) ) {
	define( 'LASR_PRO_AI_ENDPOINT', 'https://leymish-ai.leymish.workers.dev' );
}
