<?php
/**
 * Pro on the Impact tab: the work Pro did, AI fixes used and left, and a before/after report to download.
 *
 * @package LeyMish_AI_Shopping_Readiness_Pro
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Work log (counts only, stored on this site) plus the Impact section and the report.
 */
class LASR_Pro_Impact {

	const WORKLOG = 'lasr_pro_worklog';

	/**
	 * Hooks.
	 */
	public static function init() {
		add_action( 'lasr_impact_hero', array( __CLASS__, 'hero' ), 10, 3 );
		add_action( 'lasr_impact_after', array( __CLASS__, 'render' ), 10, 3 );
		add_action( 'admin_post_lasr_pro_report', array( __CLASS__, 'handle_report' ) );
	}

	/**
	 * Labels for each kind of work.
	 *
	 * @return array<string,string>
	 */
	public static function kinds() {
		return array(
			'identifiers' => __( 'Products given a GTIN, MPN or brand in the bulk editor', 'leymish-ai-shopping-readiness-pro' ),
			'attributes'  => __( 'AI attribute suggestions you applied', 'leymish-ai-shopping-readiness-pro' ),
			'description' => __( 'AI descriptions you applied', 'leymish-ai-shopping-readiness-pro' ),
			'category'    => __( 'AI Google categories you applied', 'leymish-ai-shopping-readiness-pro' ),
			'alt_text'    => __( 'AI image alt texts you applied', 'leymish-ai-shopping-readiness-pro' ),
		);
	}

	/**
	 * The log: totals per kind, the 50 most recent entries, and when logging started.
	 *
	 * @return array{counts:array<string,int>,recent:array,since:int}
	 */
	public static function worklog() {
		$w = get_option( self::WORKLOG );
		return is_array( $w ) ? $w : array( 'counts' => array(), 'recent' => array(), 'since' => 0 );
	}

	/**
	 * Add one entry (pure; log() saves it).
	 *
	 * @param array  $log        Current log.
	 * @param string $kind       One of kinds().
	 * @param int    $product_id Product ID.
	 * @param int    $now        Timestamp (tests pass one).
	 * @return array The new log.
	 */
	public static function add( array $log, $kind, $product_id, $now ) {
		if ( ! $log['since'] ) {
			$log['since'] = $now;
		}
		$log['counts'][ $kind ] = ( isset( $log['counts'][ $kind ] ) ? (int) $log['counts'][ $kind ] : 0 ) + 1;
		$log['recent'][]        = array( 't' => $now, 'kind' => $kind, 'id' => (int) $product_id );
		$log['recent']          = array_slice( $log['recent'], -50 );
		return $log;
	}

	/**
	 * Record one piece of work.
	 *
	 * @param string $kind       One of kinds().
	 * @param int    $product_id Product ID.
	 */
	public static function log( $kind, $product_id ) {
		update_option( self::WORKLOG, self::add( self::worklog(), $kind, $product_id, time() ), false );
	}

	/**
	 * "Work done by Pro" as the Impact tab's second hero (free 1.4.0 calls this right under the area cards): the score
	 * then and now, a before/after chart of the product data, and the work counted.
	 *
	 * @param array[] $history  Snapshots.
	 * @param array   $baseline Baseline.
	 * @param array   $result   Last audit.
	 */
	public static function hero( $history, $baseline, $result ) {
		self::$hero_done = true;
		$log     = self::worklog();
		$current = $history ? end( $history ) : null;
		echo '<section class="lasr-pro-hero" aria-labelledby="lasr-pro-hero-h"><h2 id="lasr-pro-hero-h">' . esc_html__( 'Work done by Pro', 'leymish-ai-shopping-readiness-pro' ) . '</h2>';
		if ( $current && $baseline ) {
			echo '<p class="lasr-then-now-score"><span class="lasr-big">' . esc_html( (int) $baseline['s'] . ' → ' . (int) $current['s'] ) . '</span> <span class="description">' . esc_html__( 'audit score out of 100, from your first audit to now', 'leymish-ai-shopping-readiness-pro' ) . '</span></p>';
			self::before_after( $baseline, $current );
		}
		$tiles = '';
		foreach ( self::kinds() as $k => $label ) {
			if ( ! empty( $log['counts'][ $k ] ) ) {
				$tiles .= '<li class="lasr-card lasr-tile"><span class="lasr-tile-label">' . esc_html( $label ) . '</span> <span class="lasr-tile-num">' . esc_html( (string) (int) $log['counts'][ $k ] ) . '</span></li>';
			}
		}
		if ( $tiles ) {
			echo '<ul class="lasr-cards lasr-tiles">' . $tiles . '</ul>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- escaped above.
			/* translators: %s: date logging started. */
			echo '<p class="description">' . esc_html( sprintf( __( 'Since %s. Every change was reviewed and saved by you.', 'leymish-ai-shopping-readiness-pro' ), wp_date( get_option( 'date_format' ), (int) $log['since'] ) ) ) . '</p>';
		} else {
			echo '<p>' . esc_html__( 'Nothing yet. Changes you save in the bulk editor or apply from AI fixes are counted here.', 'leymish-ai-shopping-readiness-pro' ) . '</p>';
		}
		echo '</section>';
	}

	/**
	 * Whether hero() already ran on this page (older free versions don't have the hook, so render() calls it).
	 *
	 * @var bool
	 */
	private static $hero_done = false;

	/**
	 * Paired bars per product-data row (start vs now), with the same numbers in a screen-reader table.
	 *
	 * @param array $baseline Baseline snapshot.
	 * @param array $current  Latest snapshot.
	 */
	private static function before_after( array $baseline, array $current ) {
		$names = array(
			'identifier' => __( 'Valid GTIN or MPN', 'leymish-ai-shopping-readiness-pro' ),
			'brand'      => __( 'Brand', 'leymish-ai-shopping-readiness-pro' ),
			'alt'        => __( 'Main image has alt text', 'leymish-ai-shopping-readiness-pro' ),
		);
		$rows  = array();
		foreach ( LASR_Impact::product_rows( $baseline, $current ) as $r ) {
			if ( null !== $r['then'] && null !== $r['now'] ) {
				$rows[] = $r;
			}
		}
		if ( ! $rows ) {
			return;
		}
		$h = 30 + 46 * count( $rows );
		echo '<figure class="lasr-ba"><svg viewBox="0 0 640 ' . esc_attr( (string) $h ) . '" aria-hidden="true" focusable="false">';
		echo '<rect class="lasr-ba-then" x="190" y="4" width="12" height="12" rx="2" /><text class="lasr-axis" x="208" y="15">' . esc_html__( 'At the start', 'leymish-ai-shopping-readiness-pro' ) . '</text>';
		echo '<rect class="lasr-ba-now" x="320" y="4" width="12" height="12" rx="2" /><text class="lasr-axis" x="338" y="15">' . esc_html__( 'Now', 'leymish-ai-shopping-readiness-pro' ) . '</text>';
		$y = 30;
		foreach ( $rows as $r ) {
			$w1 = round( 380 * $r['then_pct'] / 100, 1 );
			$w2 = round( 380 * $r['now_pct'] / 100, 1 );
			echo '<text class="lasr-axis" x="0" y="' . esc_attr( (string) ( $y + 16 ) ) . '">' . esc_html( $names[ $r['key'] ] ) . '</text>';
			echo '<rect class="lasr-ba-then" x="190" y="' . esc_attr( (string) $y ) . '" width="' . esc_attr( (string) max( 1, $w1 ) ) . '" height="14" rx="3" />';
			echo '<text class="lasr-axis" x="' . esc_attr( (string) ( 196 + $w1 ) ) . '" y="' . esc_attr( (string) ( $y + 12 ) ) . '">' . esc_html( $r['then_pct'] . '%' ) . '</text>';
			echo '<rect class="lasr-ba-now" x="190" y="' . esc_attr( (string) ( $y + 18 ) ) . '" width="' . esc_attr( (string) max( 1, $w2 ) ) . '" height="14" rx="3" />';
			echo '<text class="lasr-axis" x="' . esc_attr( (string) ( 196 + $w2 ) ) . '" y="' . esc_attr( (string) ( $y + 30 ) ) . '">' . esc_html( $r['now_pct'] . '%' ) . '</text>';
			$y += 46;
		}
		echo '</svg></figure>';
		echo '<table class="screen-reader-text"><caption>' . esc_html__( 'Product data at the start and now', 'leymish-ai-shopping-readiness-pro' ) . '</caption><thead><tr><th scope="col">' . esc_html__( 'Products with…', 'leymish-ai-shopping-readiness-pro' ) . '</th><th scope="col">' . esc_html__( 'At the start', 'leymish-ai-shopping-readiness-pro' ) . '</th><th scope="col">' . esc_html__( 'Now', 'leymish-ai-shopping-readiness-pro' ) . '</th></tr></thead><tbody>';
		foreach ( $rows as $r ) {
			echo '<tr><th scope="row">' . esc_html( $names[ $r['key'] ] ) . '</th><td>' . esc_html( $r['then_pct'] . '%' ) . '</td><td>' . esc_html( $r['now_pct'] . '%' ) . '</td></tr>';
		}
		echo '</tbody></table>';
	}

	/**
	 * The rest of Pro on the Impact tab: AI fixes as a meter, and the report.
	 *
	 * @param array[] $history  Snapshots.
	 * @param array   $baseline Baseline.
	 * @param array   $result   Last audit.
	 */
	public static function render( $history, $baseline, $result ) {
		if ( ! self::$hero_done ) {
			self::hero( $history, $baseline, $result );
		}
		if ( class_exists( 'LASR_Pro_AI' ) ) {
			$u = LASR_Pro_AI::usage();
			echo '<h2>' . esc_html__( 'AI fixes', 'leymish-ai-shopping-readiness-pro' ) . '</h2>';
			if ( isset( $u['used'], $u['limit'] ) && (int) $u['limit'] > 0 ) {
				$pct = (int) min( 100, round( 100 * (int) $u['used'] / (int) $u['limit'] ) );
				echo '<div class="lasr-meter-wrap"><div class="lasr-bar lasr-meter" role="meter" aria-label="' . esc_attr__( 'AI fixes used', 'leymish-ai-shopping-readiness-pro' ) . '" aria-valuemin="0" aria-valuemax="' . esc_attr( (string) (int) $u['limit'] ) . '" aria-valuenow="' . esc_attr( (string) (int) $u['used'] ) . '"><span style="width:' . esc_attr( (string) $pct ) . '%"></span></div>';
				/* translators: 1: fixes used, 2: fixes included, 3: fixes left. */
				echo '<p>' . esc_html( sprintf( __( '%1$d of %2$d used, %3$d left.', 'leymish-ai-shopping-readiness-pro' ), (int) $u['used'], (int) $u['limit'], (int) $u['remaining'] ) ) . ' <a href="' . esc_url( admin_url( 'admin.php?page=' . LASR_Pro_AI::SLUG ) ) . '">' . esc_html__( 'Open AI fixes', 'leymish-ai-shopping-readiness-pro' ) . '</a></p></div>';
			} else {
				echo '<p>' . esc_html__( 'Fix counts are not available right now. Try again in a few minutes.', 'leymish-ai-shopping-readiness-pro' ) . '</p>';
			}
		}

		echo '<h2>' . esc_html__( 'Before and after report', 'leymish-ai-shopping-readiness-pro' ) . '</h2>';
		if ( LASR_Pro_License::is_active() ) {
			echo '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '">';
			wp_nonce_field( 'lasr_pro_report' );
			echo '<input type="hidden" name="action" value="lasr_pro_report" />';
			submit_button( __( 'Download report (HTML)', 'leymish-ai-shopping-readiness-pro' ), 'secondary', 'submit', false );
			echo ' <span class="description">' . esc_html__( 'One page you can open in any browser, print or save as PDF.', 'leymish-ai-shopping-readiness-pro' ) . '</span></form>';
		} else {
			echo '<p>' . esc_html__( 'Activate your license on the AI Readiness Pro screen to download a before/after report.', 'leymish-ai-shopping-readiness-pro' ) . '</p>';
		}
	}

	/**
	 * Download the report.
	 */
	public static function handle_report() {
		if ( ! current_user_can( 'manage_woocommerce' ) || ! LASR_Pro_License::is_active() ) {
			wp_die( esc_html__( 'You do not have permission to do that.', 'leymish-ai-shopping-readiness-pro' ) );
		}
		check_admin_referer( 'lasr_pro_report' );
		$result   = LASR_Audit::last();
		$history  = LASR_Impact::history();
		$baseline = LASR_Impact::baseline();
		if ( ! $result || ! $history || ! $baseline ) {
			wp_die( esc_html__( 'Run the audit first.', 'leymish-ai-shopping-readiness-pro' ) );
		}
		nocache_headers();
		header( 'Content-Type: text/html; charset=utf-8' );
		header( 'Content-Disposition: attachment; filename=ai-readiness-report-' . gmdate( 'Y-m-d' ) . '.html' );
		echo self::report_html( $history, $baseline, $result, self::worklog() ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- built from escaped parts in report_html().
		exit;
	}

	/**
	 * The report as one self-contained HTML page.
	 *
	 * @param array[] $history  Snapshots.
	 * @param array   $baseline Baseline.
	 * @param array   $result   Last audit.
	 * @param array   $log      Work log.
	 * @return string
	 */
	public static function report_html( array $history, array $baseline, array $result, array $log ) {
		$current = end( $history );
		$date    = get_option( 'date_format' );
		$labels  = array();
		foreach ( $result['checks'] as $c ) {
			$labels[ $c['id'] ] = $c['label'];
		}
		$changes = LASR_Impact::changes( $baseline, $current );
		ob_start();
		LASR_Admin::chart( $history );
		$chart = ob_get_clean();
		$names = array(
			'identifier' => __( 'Valid GTIN or MPN', 'leymish-ai-shopping-readiness-pro' ),
			'brand'      => __( 'Brand', 'leymish-ai-shopping-readiness-pro' ),
			'alt'        => __( 'Main image has alt text', 'leymish-ai-shopping-readiness-pro' ),
		);
		$rows = '';
		foreach ( LASR_Impact::product_rows( $baseline, $current ) as $r ) {
			$then  = null === $r['then'] ? '—' : $r['then'] . ' (' . $r['then_pct'] . '%)';
			$now   = null === $r['now'] ? '—' : $r['now'] . ' (' . $r['now_pct'] . '%)';
			$rows .= '<tr><th scope="row">' . esc_html( $names[ $r['key'] ] ) . '</th><td>' . esc_html( $then ) . '</td><td>' . esc_html( $now ) . '</td></tr>';
		}
		$fixed = '';
		foreach ( $changes['fixed'] as $id ) {
			$fixed .= '<li>' . esc_html( isset( $labels[ $id ] ) ? $labels[ $id ] : $id ) . '</li>';
		}
		$work = '';
		foreach ( self::kinds() as $k => $label ) {
			if ( ! empty( $log['counts'][ $k ] ) ) {
				$work .= '<tr><th scope="row">' . esc_html( $label ) . '</th><td>' . esc_html( (string) (int) $log['counts'][ $k ] ) . '</td></tr>';
			}
		}
		$next = '';
		foreach ( array_slice( LASR_Scoring::fix_list( $result['checks'] ), 0, 3 ) as $f ) {
			$next .= '<li><strong>' . esc_html( $f['label'] ) . '</strong>: ' . esc_html( $f['fix'] ) . '</li>';
		}
		$title = sprintf(
			/* translators: %s: site name. */
			__( 'AI shopping readiness: %s', 'leymish-ai-shopping-readiness-pro' ),
			get_bloginfo( 'name' )
		);
		$css = 'body{font:15px/1.5 -apple-system,BlinkMacSystemFont,"Segoe UI",Roboto,sans-serif;color:#1d2327;max-width:760px;margin:32px auto;padding:0 16px}'
			. 'h1{font-size:24px}h2{font-size:18px;margin-top:28px}table{border-collapse:collapse;width:100%}th,td{text-align:left;padding:6px 8px;border-bottom:1px solid #dcdcde}'
			. '.big{font-size:40px;font-weight:700}.muted{color:#50575e}.screen-reader-text{position:absolute;left:-9999px}'
			. 'svg{width:100%;height:auto;border:1px solid #dcdcde;border-radius:8px}.lasr-grid{stroke:#dcdcde}.lasr-axis{fill:#50575e;font-size:12px}.lasr-line{fill:none;stroke:#2271b1;stroke-width:2.5}.lasr-dot{fill:#2271b1}'
			. '@media print{body{margin:0}}';
		return '<!doctype html><html lang="' . esc_attr( get_bloginfo( 'language' ) ) . '"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1"><title>' . esc_html( $title ) . '</title><style>' . $css . '</style></head><body>'
			. '<h1>' . esc_html( $title ) . '</h1>'
			/* translators: 1: first audit date, 2: latest audit date. */
			. '<p class="muted">' . esc_html( sprintf( __( 'From %1$s to %2$s. Made by LeyMish AI Shopping Readiness Pro on this site.', 'leymish-ai-shopping-readiness-pro' ), wp_date( $date, (int) $baseline['t'] ), wp_date( $date, (int) $current['t'] ) ) ) . '</p>'
			/* translators: 1: starting score, 2: current score. */
			. '<p><span class="big">' . esc_html( (int) $baseline['s'] . ' → ' . (int) $current['s'] ) . '</span> <span class="muted">' . esc_html__( 'audit score out of 100', 'leymish-ai-shopping-readiness-pro' ) . '</span></p>'
			. $chart
			. '<h2>' . esc_html__( 'Checks fixed', 'leymish-ai-shopping-readiness-pro' ) . '</h2>' . ( $fixed ? '<ul>' . $fixed . '</ul>' : '<p>' . esc_html__( 'None yet.', 'leymish-ai-shopping-readiness-pro' ) . '</p>' )
			. '<h2>' . esc_html__( 'Product data', 'leymish-ai-shopping-readiness-pro' ) . '</h2><table><thead><tr><th scope="col">' . esc_html__( 'Products with…', 'leymish-ai-shopping-readiness-pro' ) . '</th><th scope="col">' . esc_html__( 'At the start', 'leymish-ai-shopping-readiness-pro' ) . '</th><th scope="col">' . esc_html__( 'Now', 'leymish-ai-shopping-readiness-pro' ) . '</th></tr></thead><tbody>' . $rows . '</tbody></table>'
			. ( $work ? '<h2>' . esc_html__( 'Work done with Pro', 'leymish-ai-shopping-readiness-pro' ) . '</h2><table><tbody>' . $work . '</tbody></table>' : '' )
			. ( $next ? '<h2>' . esc_html__( 'Next', 'leymish-ai-shopping-readiness-pro' ) . '</h2><ol>' . $next . '</ol>' : '' )
			. '</body></html>';
	}
}
