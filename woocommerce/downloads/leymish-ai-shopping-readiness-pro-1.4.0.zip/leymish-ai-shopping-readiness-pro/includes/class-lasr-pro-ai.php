<?php
/**
 * Pro AI: one-click suggestions for product data, reviewed by the merchant before anything is saved.
 * Sends only the selected product's text (and its main image URL for alt text) to the LeyMish AI proxy, and only
 * after the merchant has ticked the consent box. Never writes a GTIN, EAN, UPC, MPN or ISBN.
 *
 * @package LeyMish_AI_Shopping_Readiness_Pro
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * The "AI fixes" screen, its settings and its AJAX routes.
 */
class LASR_Pro_AI {

	const SLUG   = 'lasr-pro-ai';
	const OPTION = 'lasr_pro_ai';
	const NONCE  = 'lasr_pro_ai';

	/**
	 * Hooks (admin only).
	 */
	public static function init() {
		add_action( 'admin_menu', array( __CLASS__, 'menu' ), 62 );
		add_action( 'admin_post_lasr_pro_ai_settings', array( __CLASS__, 'handle_settings' ) );
		add_action( 'wp_ajax_lasr_pro_ai_suggest', array( __CLASS__, 'ajax_suggest' ) );
		add_action( 'wp_ajax_lasr_pro_ai_apply', array( __CLASS__, 'ajax_apply' ) );
		add_action( 'admin_enqueue_scripts', array( __CLASS__, 'assets' ) );
	}

	/**
	 * Proxy base URL (set at build time; filterable for testing).
	 *
	 * @return string
	 */
	public static function endpoint() {
		$url = defined( 'LASR_PRO_AI_ENDPOINT' ) ? LASR_PRO_AI_ENDPOINT : '';
		return untrailingslashit( (string) apply_filters( 'lasr_pro_ai_endpoint', $url ) );
	}

	/**
	 * Saved settings.
	 *
	 * @return array{key:string,consent:bool}
	 */
	public static function settings() {
		$s   = get_option( self::OPTION, array() );
		$key = isset( $s['key'] ) ? (string) $s['key'] : '';
		// One key for both: an active Pro AI licence entered on the Pro screen is used here too (P-015).
		if ( '' === $key && class_exists( 'LASR_Pro_License' ) && LASR_Pro_License::is_pro_ai() ) {
			$lic = LASR_Pro_License::state();
			$key = (string) $lic['key'];
		}
		return array(
			'key'     => $key,
			'consent' => ! empty( $s['consent'] ),
		);
	}

	/**
	 * Submenu under WooCommerce.
	 */
	public static function menu() {
		add_submenu_page( 'woocommerce', __( 'AI fixes', 'leymish-ai-shopping-readiness-pro' ), __( 'AI fixes', 'leymish-ai-shopping-readiness-pro' ), 'manage_woocommerce', self::SLUG, array( __CLASS__, 'render' ) );
	}

	/**
	 * Script for the review panel, only on our screen.
	 *
	 * @param string $hook Current admin page hook.
	 */
	public static function assets( $hook ) {
		if ( false === strpos( (string) $hook, self::SLUG ) ) {
			return;
		}
		wp_enqueue_script( 'lasr-pro-ai', plugins_url( 'assets/pro-ai.js', LASR_PRO_FILE ), array(), LASR_PRO_VERSION, true );
		wp_localize_script(
			'lasr-pro-ai',
			'lasrProAI',
			array(
				'ajax'  => admin_url( 'admin-ajax.php' ),
				'nonce' => wp_create_nonce( self::NONCE ),
				'i18n'  => array(
					'working' => __( 'Asking for a suggestion…', 'leymish-ai-shopping-readiness-pro' ),
					'apply'   => __( 'Apply selected', 'leymish-ai-shopping-readiness-pro' ),
					'cancel'  => __( 'Discard', 'leymish-ai-shopping-readiness-pro' ),
					'saved'   => __( 'Saved. Check the product page.', 'leymish-ai-shopping-readiness-pro' ),
					'current' => __( 'Now', 'leymish-ai-shopping-readiness-pro' ),
					'suggest' => __( 'Suggested', 'leymish-ai-shopping-readiness-pro' ),
					'none'    => __( 'No suggestion: nothing in the product text supports one.', 'leymish-ai-shopping-readiness-pro' ),
				),
			)
		);
	}

	/**
	 * Save the consent box and the licence key.
	 */
	public static function handle_settings() {
		if ( ! current_user_can( 'manage_woocommerce' ) ) {
			wp_die( esc_html__( 'You do not have permission to do that.', 'leymish-ai-shopping-readiness-pro' ) );
		}
		check_admin_referer( 'lasr_pro_ai_settings' );
		update_option(
			self::OPTION,
			array(
				'key'     => isset( $_POST['lasr_ai_key'] ) ? sanitize_text_field( wp_unslash( $_POST['lasr_ai_key'] ) ) : '',
				'consent' => ! empty( $_POST['lasr_ai_consent'] ),
			),
			false
		);
		delete_transient( 'lasr_pro_ai_usage' );
		wp_safe_redirect( admin_url( 'admin.php?page=' . self::SLUG . '&lasr_msg=saved' ) );
		exit;
	}

	/**
	 * POST JSON to the proxy.
	 *
	 * @param string $path  /v1/fix or /v1/usage.
	 * @param array  $body  Request body.
	 * @return array{status:int,data:array}
	 */
	private static function call( $path, $body ) {
		$r = wp_remote_post(
			self::endpoint() . $path,
			array(
				'timeout' => 45,
				'headers' => array( 'Content-Type' => 'application/json' ),
				'body'    => wp_json_encode( $body ),
			)
		);
		if ( is_wp_error( $r ) ) {
			return array( 'status' => 0, 'data' => array( 'error' => $r->get_error_message() ) );
		}
		$data = json_decode( (string) wp_remote_retrieve_body( $r ), true );
		return array( 'status' => (int) wp_remote_retrieve_response_code( $r ), 'data' => is_array( $data ) ? $data : array() );
	}

	/**
	 * Fixes used and left (cached 5 minutes).
	 *
	 * @return array
	 */
	public static function usage() {
		$u = get_transient( 'lasr_pro_ai_usage' );
		if ( is_array( $u ) ) {
			return $u;
		}
		$s    = self::settings();
		$body = array( 'site' => home_url( '/' ) );
		if ( '' !== $s['key'] ) {
			$body['license_key'] = $s['key'];
		}
		$r = self::call( '/v1/usage', $body );
		$u = 200 === $r['status'] ? $r['data'] : array( 'error' => isset( $r['data']['error'] ) ? $r['data']['error'] : '' );
		set_transient( 'lasr_pro_ai_usage', $u, 5 * MINUTE_IN_SECONDS );
		return $u;
	}

	/**
	 * The product fields Pro AI may send, for one product.
	 *
	 * @param WC_Product $p Product.
	 * @return array
	 */
	private static function product_data( $p ) {
		$attrs = array();
		foreach ( $p->get_attributes() as $a ) {
			$name           = $a->is_taxonomy() ? wc_attribute_label( $a->get_name() ) : $a->get_name();
			$values         = $a->is_taxonomy() ? wc_get_product_terms( $p->get_id(), $a->get_name(), array( 'fields' => 'names' ) ) : $a->get_options();
			$attrs[ $name ] = implode( ', ', (array) $values );
		}
		$cats = wc_get_product_terms( $p->get_id(), 'product_cat', array( 'fields' => 'names' ) );
		$img  = $p->get_image_id() ? wp_get_attachment_image_url( $p->get_image_id(), 'large' ) : '';
		return array(
			'name'              => $p->get_name(),
			'description'       => $p->get_description(),
			'short_description' => $p->get_short_description(),
			'attributes'        => $attrs,
			'categories'        => is_array( $cats ) ? $cats : array(),
			'image_url'         => $img ? $img : '',
			'image_alt'         => $p->get_image_id() ? (string) get_post_meta( $p->get_image_id(), '_wp_attachment_image_alt', true ) : '',
			'google_category'   => (string) $p->get_meta( '_lasr_google_product_category' ),
		);
	}

	/**
	 * Common AJAX guard; returns the product.
	 *
	 * @return WC_Product
	 */
	private static function ajax_guard() {
		check_ajax_referer( self::NONCE, 'nonce' );
		if ( ! current_user_can( 'manage_woocommerce' ) ) {
			wp_send_json_error( array( 'message' => __( 'You do not have permission to do that.', 'leymish-ai-shopping-readiness-pro' ) ), 403 );
		}
		$p = wc_get_product( isset( $_POST['product'] ) ? absint( $_POST['product'] ) : 0 );
		if ( ! $p ) {
			wp_send_json_error( array( 'message' => __( 'Product not found.', 'leymish-ai-shopping-readiness-pro' ) ), 404 );
		}
		return $p;
	}

	/**
	 * Ask the proxy for one suggestion. Nothing is saved here.
	 */
	public static function ajax_suggest() {
		$p    = self::ajax_guard();
		$s    = self::settings();
		$kind = isset( $_POST['kind'] ) ? sanitize_key( wp_unslash( $_POST['kind'] ) ) : '';
		if ( ! $s['consent'] || '' === self::endpoint() || ! in_array( $kind, LASR_Pro_AI_Logic::KINDS, true ) ) {
			wp_send_json_error( array( 'message' => __( 'Tick the consent box in the settings above first.', 'leymish-ai-shopping-readiness-pro' ) ), 400 );
		}
		$data = self::product_data( $p );
		$r    = self::call( '/v1/fix', LASR_Pro_AI_Logic::payload( $kind, $data, home_url( '/' ), $s['key'], LASR_PRO_VERSION ) );
		delete_transient( 'lasr_pro_ai_usage' );
		if ( 200 !== $r['status'] || empty( $r['data']['ok'] ) ) {
			$msg = isset( $r['data']['error'] ) ? (string) $r['data']['error'] : __( 'No suggestion this time.', 'leymish-ai-shopping-readiness-pro' );
			wp_send_json_error( array( 'message' => $msg, 'remaining' => isset( $r['data']['remaining'] ) ? (int) $r['data']['remaining'] : null ), $r['status'] ? $r['status'] : 502 );
		}
		$current = array(
			'attributes'  => array( 'attributes' => $data['attributes'] ),
			'description' => array( 'description' => $data['description'], 'short_description' => $data['short_description'] ),
			'category'    => array( 'categories' => $data['categories'], 'google' => $data['google_category'] ),
			'alt_text'    => array( 'alt_text' => $data['image_alt'], 'image' => $data['image_url'] ),
		);
		wp_send_json_success(
			array(
				'kind'       => $kind,
				'current'    => $current[ $kind ],
				'suggestion' => LASR_Pro_AI_Logic::clean( $kind, isset( $r['data']['suggestion'] ) ? $r['data']['suggestion'] : array() ),
				'remaining'  => isset( $r['data']['remaining'] ) ? (int) $r['data']['remaining'] : null,
			)
		);
	}

	/**
	 * Save what the merchant accepted in the review panel.
	 */
	public static function ajax_apply() {
		$p        = self::ajax_guard();
		$kind     = isset( $_POST['kind'] ) ? sanitize_key( wp_unslash( $_POST['kind'] ) ) : '';
		$accepted = isset( $_POST['accepted'] ) ? json_decode( wp_unslash( $_POST['accepted'] ), true ) : array(); // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- cleaned by LASR_Pro_AI_Logic::clean().
		$clean    = LASR_Pro_AI_Logic::clean( $kind, $accepted );
		switch ( $kind ) {
			case 'attributes':
				$attrs = $p->get_attributes();
				$have  = array();
				foreach ( $attrs as $a ) {
					$have[] = strtolower( $a->is_taxonomy() ? wc_attribute_label( $a->get_name() ) : $a->get_name() );
				}
				foreach ( $clean['attributes'] as $row ) {
					if ( in_array( strtolower( $row['name'] ), $have, true ) ) {
						continue; // never overwrite an attribute the merchant already set
					}
					$a = new WC_Product_Attribute();
					$a->set_name( $row['name'] );
					$a->set_options( array( $row['value'] ) );
					$a->set_visible( true );
					$a->set_variation( false );
					$attrs[] = $a;
				}
				$p->set_attributes( $attrs );
				break;
			case 'description':
				if ( '' !== $clean['description'] ) {
					$p->set_description( wp_kses_post( $clean['description'] ) );
				}
				if ( '' !== $clean['short_description'] ) {
					$p->set_short_description( wp_kses_post( $clean['short_description'] ) );
				}
				break;
			case 'category':
				if ( ! empty( $clean['categories'][0]['path'] ) ) {
					$p->update_meta_data( '_lasr_google_product_category', $clean['categories'][0]['path'] );
				}
				break;
			case 'alt_text':
				if ( $p->get_image_id() && '' !== $clean['alt_text'] ) {
					update_post_meta( $p->get_image_id(), '_wp_attachment_image_alt', $clean['alt_text'] );
				}
				break;
			default:
				wp_send_json_error( array( 'message' => 'kind' ), 400 );
		}
		$p->save();
		if ( class_exists( 'LASR_Pro_Impact' ) ) {
			LASR_Pro_Impact::log( $kind, $p->get_id() );
		}
		wp_send_json_success( array( 'saved' => true ) );
	}

	/**
	 * The screen.
	 */
	public static function render() {
		if ( ! current_user_can( 'manage_woocommerce' ) ) {
			return;
		}
		$s = self::settings();
		echo '<div class="wrap lasr-ai"><h1>' . esc_html__( 'AI fixes', 'leymish-ai-shopping-readiness-pro' ) . '</h1>';
		if ( isset( $_GET['lasr_msg'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- display only.
			echo '<div class="notice notice-success is-dismissible"><p>' . esc_html__( 'Settings saved.', 'leymish-ai-shopping-readiness-pro' ) . '</p></div>';
		}
		echo '<p>' . esc_html__( 'Pro AI suggests missing attributes (only ones stated in your product text), a clearer spec-first description, a Google product category and image alt text. You review every suggestion; nothing is saved until you click Apply. It never creates GTINs, EANs, UPCs or MPNs: those must come from you or your supplier.', 'leymish-ai-shopping-readiness-pro' ) . '</p>';

		if ( '' === self::endpoint() ) {
			echo '<div class="notice notice-info inline"><p>' . esc_html__( 'Pro AI is not switched on in this version yet. Your Pro tools work as usual.', 'leymish-ai-shopping-readiness-pro' ) . '</p></div></div>';
			return;
		}

		echo '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '">';
		wp_nonce_field( 'lasr_pro_ai_settings' );
		echo '<input type="hidden" name="action" value="lasr_pro_ai_settings" /><table class="form-table"><tr><th scope="row">' . esc_html__( 'Privacy', 'leymish-ai-shopping-readiness-pro' ) . '</th><td><label><input type="checkbox" name="lasr_ai_consent" value="1" ' . checked( $s['consent'], true, false ) . ' /> ';
		echo esc_html__( 'Send the selected product\'s name, descriptions, attributes, categories and main image URL to LeyMish AI for suggestions.', 'leymish-ai-shopping-readiness-pro' ) . '</label>';
		echo '<p class="description">' . esc_html__( 'Only the product you click is sent, and only when you click. No customer, order or personal data is ever sent. LeyMish AI keeps counters, not your product text, and the AI provider does not train on it.', 'leymish-ai-shopping-readiness-pro' ) . '</p></td></tr>';
		echo '<tr><th scope="row"><label for="lasr_ai_key">' . esc_html__( 'Pro AI licence key', 'leymish-ai-shopping-readiness-pro' ) . '</label></th><td><input type="text" class="regular-text" id="lasr_ai_key" name="lasr_ai_key" value="' . esc_attr( $s['key'] ) . '" autocomplete="off" />';
		echo '<p class="description">' . esc_html__( 'Optional. A Pro AI key entered on the AI Readiness Pro screen is used automatically. Without one you get 20 free fixes for this store.', 'leymish-ai-shopping-readiness-pro' ) . '</p></td></tr></table>';
		submit_button( __( 'Save', 'leymish-ai-shopping-readiness-pro' ) );
		echo '</form>';

		if ( ! $s['consent'] ) {
			echo '</div>';
			return;
		}
		$u     = self::usage();
		$audit = class_exists( 'LASR_Audit' ) ? LASR_Audit::last() : null;
		$rows  = $audit ? array_slice( (array) $audit['products'], 0, 50 ) : array();
		if ( isset( $u['remaining'] ) ) {
			/* translators: 1: fixes left, 2: fixes allowed. */
			echo '<p><strong>' . esc_html( sprintf( __( '%1$d of %2$d fixes left.', 'leymish-ai-shopping-readiness-pro' ), (int) $u['remaining'], (int) $u['limit'] ) ) . '</strong></p>';
			$note = LASR_Pro_AI_Logic::upgrade_note( (int) $u['used'], (int) $u['limit'], count( $rows ) );
			if ( $note && 'free' === ( isset( $u['plan'] ) ? $u['plan'] : '' ) ) {
				echo '<p class="lasr-pro">' . esc_html( $note ) . ' <a href="https://leymish.gumroad.com/l/proai" target="_blank" rel="noopener">' . esc_html__( 'Get Pro AI', 'leymish-ai-shopping-readiness-pro' ) . '</a></p>';
			}
		} elseif ( ! empty( $u['error'] ) ) {
			echo '<div class="notice notice-warning inline"><p>' . esc_html( (string) $u['error'] ) . '</p></div>';
		}
		if ( ! $rows ) {
			echo '<p>' . esc_html__( 'Run the audit first (WooCommerce → AI Readiness); the products with the most gaps appear here.', 'leymish-ai-shopping-readiness-pro' ) . '</p></div>';
			return;
		}
		echo '<table class="widefat striped"><thead><tr><th>' . esc_html__( 'Product', 'leymish-ai-shopping-readiness-pro' ) . '</th><th>' . esc_html__( 'Suggest', 'leymish-ai-shopping-readiness-pro' ) . '</th></tr></thead><tbody>';
		$labels = array(
			'attributes'  => __( 'Attributes', 'leymish-ai-shopping-readiness-pro' ),
			'description' => __( 'Description', 'leymish-ai-shopping-readiness-pro' ),
			'category'    => __( 'Google category', 'leymish-ai-shopping-readiness-pro' ),
			'alt_text'    => __( 'Alt text', 'leymish-ai-shopping-readiness-pro' ),
		);
		foreach ( $rows as $r ) {
			echo '<tr><td><a href="' . esc_url( (string) get_edit_post_link( $r['id'] ) ) . '">' . esc_html( $r['name'] ) . '</a></td><td>';
			foreach ( $labels as $kind => $label ) {
				echo '<button type="button" class="button lasr-ai-suggest" data-product="' . esc_attr( (string) (int) $r['id'] ) . '" data-kind="' . esc_attr( $kind ) . '">' . esc_html( $label ) . '</button> ';
			}
			echo '<div class="lasr-ai-panel" id="lasr-ai-' . esc_attr( (string) (int) $r['id'] ) . '"></div></td></tr>';
		}
		echo '</tbody></table></div>';
	}
}
