<?php
/**
 * Weekly re-audit email, license re-check and score history.
 *
 * @package LeyMish_AI_Shopping_Readiness_Pro
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Scheduled jobs.
 */
class LASR_Pro_Schedule {

	const HISTORY     = 'lasr_pro_history';
	const EMAIL_OPT   = 'lasr_pro_weekly_email';
	const MAX_HISTORY = 104;

	/**
	 * Hooks.
	 */
	public static function init() {
		add_action( 'lasr_pro_weekly', array( __CLASS__, 'weekly' ) );
		add_action( 'lasr_audit_completed', array( __CLASS__, 'record' ) );
		if ( ! wp_next_scheduled( 'lasr_pro_weekly' ) ) {
			self::schedule();
		}
	}

	/**
	 * Schedule the weekly jobs.
	 */
	public static function schedule() {
		if ( ! wp_next_scheduled( 'lasr_pro_weekly' ) ) {
			wp_schedule_event( time() + HOUR_IN_SECONDS, 'weekly', 'lasr_pro_weekly' );
		}
		if ( ! wp_next_scheduled( 'lasr_pro_license_recheck' ) ) {
			wp_schedule_event( time() + DAY_IN_SECONDS, 'weekly', 'lasr_pro_license_recheck' );
		}
	}

	/**
	 * Remove the scheduled jobs.
	 */
	public static function unschedule() {
		wp_clear_scheduled_hook( 'lasr_pro_weekly' );
		wp_clear_scheduled_hook( 'lasr_pro_license_recheck' );
		wp_clear_scheduled_hook( 'lasr_pro_rebuild_feeds' );
	}

	/**
	 * Store each audit's score (most recent last).
	 *
	 * @param array $result Audit result.
	 */
	public static function record( $result ) {
		if ( ! LASR_Pro_License::is_active() ) {
			return;
		}
		$history   = self::history();
		$history[] = array(
			't' => (int) $result['ran_at'],
			's' => (int) $result['score'],
		);
		update_option( self::HISTORY, array_slice( $history, -self::MAX_HISTORY ), false );
	}

	/**
	 * Score history.
	 *
	 * @return array<int,array{t:int,s:int}>
	 */
	public static function history() {
		$h = get_option( self::HISTORY );
		return is_array( $h ) ? $h : array();
	}

	/**
	 * Weekly: re-run the audit and email the admin if the email is switched on.
	 */
	public static function weekly() {
		if ( ! LASR_Pro_License::is_active() ) {
			return;
		}
		$before = self::history();
		$prev   = $before ? end( $before ) : null;
		$result = LASR_Audit::run();
		if ( 'yes' === get_option( self::EMAIL_OPT, 'yes' ) ) {
			wp_mail( get_option( 'admin_email' ), self::subject( $result, $prev ), self::body( $result, $prev ) );
		}
	}

	/**
	 * Email subject.
	 *
	 * @param array      $result Audit result.
	 * @param array|null $prev   Previous history entry.
	 * @return string
	 */
	public static function subject( array $result, $prev ) {
		$delta = $prev ? (int) $result['score'] - (int) $prev['s'] : null;
		/* translators: 1: store name, 2: score. */
		$subject = sprintf( __( '%1$s: AI shopping readiness %2$d/100', 'leymish-ai-shopping-readiness-pro' ), wp_specialchars_decode( get_bloginfo( 'name' ), ENT_QUOTES ), (int) $result['score'] );
		if ( null !== $delta ) {
			/* translators: %s: signed change since the last audit, e.g. +4. */
			$subject .= ' ' . sprintf( __( '(%s since last week)', 'leymish-ai-shopping-readiness-pro' ), ( $delta >= 0 ? '+' : '' ) . $delta );
		}
		return $subject;
	}

	/**
	 * Plain-text email body with the top three fixes.
	 *
	 * @param array      $result Audit result.
	 * @param array|null $prev   Previous history entry.
	 * @return string
	 */
	public static function body( array $result, $prev ) {
		/* translators: %d: score. */
		$lines = array( sprintf( __( 'This week\'s score: %d/100.', 'leymish-ai-shopping-readiness-pro' ), (int) $result['score'] ) );
		if ( $prev ) {
			/* translators: %d: previous score. */
			$lines[] = sprintf( __( 'Last time: %d/100.', 'leymish-ai-shopping-readiness-pro' ), (int) $prev['s'] );
		}
		$fixes = array_slice( LASR_Scoring::fix_list( $result['checks'] ), 0, 3 );
		if ( $fixes ) {
			$lines[] = '';
			$lines[] = __( 'Fix these first:', 'leymish-ai-shopping-readiness-pro' );
			foreach ( $fixes as $i => $f ) {
				/* translators: 1: position, 2: check name, 3: points gained, 4: what was found. */
				$lines[] = sprintf( __( '%1$d. %2$s (+%3$s points): %4$s', 'leymish-ai-shopping-readiness-pro' ), $i + 1, $f['label'], $f['lost'], $f['detail'] );
			}
		}
		$lines[] = '';
		$lines[] = admin_url( 'admin.php?page=lasr-ai-readiness' );
		$lines[] = '';
		$lines[] = __( 'Turn this email off in WooCommerce → AI Readiness Pro.', 'leymish-ai-shopping-readiness-pro' );
		return implode( "\n", $lines );
	}
}
