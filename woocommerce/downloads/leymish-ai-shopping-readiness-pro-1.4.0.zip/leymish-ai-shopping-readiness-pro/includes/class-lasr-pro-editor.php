<?php
/**
 * Bulk editor: fill GTIN, brand and MPN for many products in one table.
 *
 * GTIN goes to WooCommerce's own "GTIN, UPC, EAN or ISBN" field when available (9.2+), brand to the
 * WooCommerce Brands taxonomy when available (9.6+), MPN to product meta. Invalid GTINs are rejected.
 *
 * @package LeyMish_AI_Shopping_Readiness_Pro
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Editor page and save handler.
 */
class LASR_Pro_Editor {

	const SLUG     = 'lasr-ai-readiness-data';
	const PER_PAGE = 50;

	/**
	 * Hooks.
	 */
	public static function init() {
		add_action( 'admin_menu', array( __CLASS__, 'menu' ), 62 );
		add_action( 'admin_post_lasr_pro_bulk_save', array( __CLASS__, 'handle_save' ) );
		add_action( 'admin_enqueue_scripts', array( __CLASS__, 'assets' ) );
	}

	/**
	 * Submenu (only with an active license).
	 */
	public static function menu() {
		if ( ! LASR_Pro_License::is_active() ) {
			return;
		}
		add_submenu_page(
			'woocommerce',
			__( 'AI Readiness: product data', 'leymish-ai-shopping-readiness-pro' ),
			__( 'AI product data', 'leymish-ai-shopping-readiness-pro' ),
			'manage_woocommerce',
			self::SLUG,
			array( __CLASS__, 'render' )
		);
	}

	/**
	 * Inline GTIN validation, only on the editor screen.
	 *
	 * @param string $hook Current admin page hook.
	 */
	public static function assets( $hook ) {
		if ( false === strpos( (string) $hook, self::SLUG ) ) {
			return;
		}
		wp_enqueue_script( 'lasr-pro-editor', plugins_url( 'assets/pro-editor.js', LASR_PRO_FILE ), array(), LASR_PRO_VERSION, true );
		wp_localize_script(
			'lasr-pro-editor',
			'lasrProEditor',
			array(
				'invalid' => __( 'Not a valid GTIN: it needs 8, 12, 13 or 14 digits and a correct check digit.', 'leymish-ai-shopping-readiness-pro' ),
				'ok'      => __( 'Valid GTIN.', 'leymish-ai-shopping-readiness-pro' ),
			)
		);
	}

	/**
	 * Save one product's identifiers. Returns an error string, or '' on success.
	 *
	 * @param WC_Product $product Product or variation.
	 * @param string     $gtin    GTIN.
	 * @param string     $brand   Brand (ignored for variations; brand belongs to the parent).
	 * @param string     $mpn     MPN.
	 * @return string
	 */
	public static function save_product( $product, $gtin, $brand, $mpn ) {
		$before = class_exists( 'LASR_Audit' ) ? array( LASR_Audit::gtin( $product ), LASR_Audit::mpn( $product ), LASR_Audit::brand( $product ) ) : null;
		$gtin   = LASR_GTIN::normalize( $gtin );
		if ( '' !== $gtin && ! LASR_GTIN::is_valid( $gtin ) ) {
			/* translators: 1: product name, 2: the GTIN entered. */
			return sprintf( __( '%1$s: "%2$s" is not a valid GTIN (8, 12, 13 or 14 digits with a correct check digit). Not saved.', 'leymish-ai-shopping-readiness-pro' ), $product->get_name(), $gtin );
		}
		if ( method_exists( $product, 'set_global_unique_id' ) ) {
			try {
				$product->set_global_unique_id( $gtin );
			} catch ( Exception $e ) {
				/* translators: 1: product name, 2: error message from WooCommerce (e.g. duplicate GTIN). */
				return sprintf( __( '%1$s: %2$s', 'leymish-ai-shopping-readiness-pro' ), $product->get_name(), $e->getMessage() );
			}
		} else {
			$product->update_meta_data( '_lasr_gtin', $gtin );
		}
		$product->update_meta_data( '_lasr_mpn', sanitize_text_field( $mpn ) );
		if ( ! $product->is_type( 'variation' ) ) {
			$brand = sanitize_text_field( $brand );
			if ( taxonomy_exists( 'product_brand' ) ) {
				wp_set_object_terms( $product->get_id(), '' === $brand ? array() : array( $brand ), 'product_brand' );
			} else {
				$product->update_meta_data( '_lasr_brand', $brand );
			}
		}
		$product->save();
		if ( null !== $before && class_exists( 'LASR_Pro_Impact' ) ) {
			$after = array( LASR_Audit::gtin( $product ), LASR_Audit::mpn( $product ), LASR_Audit::brand( $product ) );
			if ( $after !== $before && '' !== implode( '', $after ) ) { // only real changes that add data are counted
				LASR_Pro_Impact::log( 'identifiers', $product->get_id() );
			}
		}
		return '';
	}

	/**
	 * Save the submitted rows.
	 */
	public static function handle_save() {
		if ( ! current_user_can( 'manage_woocommerce' ) || ! LASR_Pro_License::is_active() ) {
			wp_die( esc_html__( 'You do not have permission to do that.', 'leymish-ai-shopping-readiness-pro' ) );
		}
		check_admin_referer( 'lasr_pro_bulk_save' );
		$rows   = isset( $_POST['lasr'] ) && is_array( $_POST['lasr'] ) ? wp_unslash( $_POST['lasr'] ) : array(); // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- each field is sanitised in save_product().
		$errors = array();
		$saved  = 0;
		foreach ( $rows as $id => $fields ) {
			$product = wc_get_product( absint( $id ) );
			if ( ! $product || ! is_array( $fields ) ) {
				continue;
			}
			$err = self::save_product(
				$product,
				isset( $fields['gtin'] ) ? (string) $fields['gtin'] : '',
				isset( $fields['brand'] ) ? (string) $fields['brand'] : '',
				isset( $fields['mpn'] ) ? (string) $fields['mpn'] : ''
			);
			if ( '' === $err ) {
				++$saved;
			} else {
				$errors[] = $err;
			}
		}
		set_transient( 'lasr_pro_bulk_result_' . get_current_user_id(), compact( 'saved', 'errors' ), 120 );
		$page = isset( $_POST['paged'] ) ? absint( $_POST['paged'] ) : 1;
		wp_safe_redirect( admin_url( 'admin.php?page=' . self::SLUG . '&paged=' . $page . ( isset( $_POST['all'] ) ? '&all=1' : '' ) ) );
		exit;
	}

	/**
	 * The table.
	 */
	public static function render() {
		if ( ! current_user_can( 'manage_woocommerce' ) ) {
			return;
		}
		// phpcs:disable WordPress.Security.NonceVerification.Recommended -- read-only paging and filter parameters.
		$paged = isset( $_GET['paged'] ) ? max( 1, absint( $_GET['paged'] ) ) : 1;
		$all   = isset( $_GET['all'] );
		// phpcs:enable
		echo '<div class="wrap lasr-wrap"><h1>' . esc_html__( 'AI product data', 'leymish-ai-shopping-readiness-pro' ) . '</h1>';
		echo '<p>' . esc_html__( 'Fill in GTIN (barcode), brand and MPN. AI shopping agents and Google match products by these identifiers; products without them are often left out. Variations have their own GTIN and MPN; brand is set on the parent product.', 'leymish-ai-shopping-readiness-pro' ) . '</p>';

		$result = get_transient( 'lasr_pro_bulk_result_' . get_current_user_id() );
		if ( is_array( $result ) ) {
			delete_transient( 'lasr_pro_bulk_result_' . get_current_user_id() );
			/* translators: %d: number of products saved. */
			echo '<div class="notice notice-success is-dismissible"><p>' . esc_html( sprintf( _n( '%d product saved.', '%d products saved.', (int) $result['saved'], 'leymish-ai-shopping-readiness-pro' ), (int) $result['saved'] ) ) . '</p></div>';
			foreach ( $result['errors'] as $e ) {
				echo '<div class="notice notice-error"><p>' . esc_html( $e ) . '</p></div>';
			}
		}

		$filter_url = admin_url( 'admin.php?page=' . self::SLUG . ( $all ? '' : '&all=1' ) );
		echo '<p><a href="' . esc_url( $filter_url ) . '">' . esc_html( $all ? __( 'Show only products missing data', 'leymish-ai-shopping-readiness-pro' ) : __( 'Show all products', 'leymish-ai-shopping-readiness-pro' ) ) . '</a></p>';

		$everything = self::items( true );
		$done       = 0;
		foreach ( $everything as $p ) {
			if ( ! self::incomplete( $p ) ) {
				++$done;
			}
		}
		if ( $everything ) {
			/* translators: 1: complete products and variations, 2: all products and variations. */
			$label = sprintf( __( '%1$d of %2$d products and variations have a GTIN or MPN and a brand', 'leymish-ai-shopping-readiness-pro' ), $done, count( $everything ) );
			echo '<div class="lasr-progress"><label for="lasr-progress">' . esc_html( $label ) . '</label> <progress id="lasr-progress" max="' . esc_attr( (string) count( $everything ) ) . '" value="' . esc_attr( (string) $done ) . '">' . esc_html( $label ) . '</progress></div>';
		}

		$items = $all ? $everything : self::items( false );
		$total = count( $items );
		$items = array_slice( $items, ( $paged - 1 ) * self::PER_PAGE, self::PER_PAGE );
		if ( ! $items ) {
			echo '<p><strong>' . esc_html__( 'Every product has a GTIN or MPN and a brand.', 'leymish-ai-shopping-readiness-pro' ) . '</strong></p></div>';
			return;
		}

		echo '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '">';
		wp_nonce_field( 'lasr_pro_bulk_save' );
		echo '<input type="hidden" name="action" value="lasr_pro_bulk_save" /><input type="hidden" name="paged" value="' . esc_attr( (string) $paged ) . '" />';
		if ( $all ) {
			echo '<input type="hidden" name="all" value="1" />';
		}
		echo '<table class="widefat striped"><thead><tr><th>' . esc_html__( 'Product', 'leymish-ai-shopping-readiness-pro' ) . '</th><th>' . esc_html__( 'GTIN / UPC / EAN', 'leymish-ai-shopping-readiness-pro' ) . '</th><th>' . esc_html__( 'Brand', 'leymish-ai-shopping-readiness-pro' ) . '</th><th>' . esc_html__( 'MPN', 'leymish-ai-shopping-readiness-pro' ) . '</th></tr></thead><tbody>';
		foreach ( $items as $p ) {
			$id     = $p->get_id();
			$is_var = $p->is_type( 'variation' );
			$name   = $is_var ? '— ' . wc_get_formatted_variation( $p, true, false, false ) : $p->get_name();
			echo '<tr><td><a href="' . esc_url( (string) get_edit_post_link( $is_var ? $p->get_parent_id() : $id ) ) . '">' . esc_html( $name ) . '</a></td>';
			echo '<td><input type="text" name="lasr[' . esc_attr( (string) $id ) . '][gtin]" value="' . esc_attr( LASR_Audit::gtin( $p ) ) . '" inputmode="numeric" class="lasr-gtin" aria-describedby="lasr-gtin-msg-' . esc_attr( (string) $id ) . '" /><span class="lasr-gtin-msg" id="lasr-gtin-msg-' . esc_attr( (string) $id ) . '" aria-live="polite"></span></td>';
			echo '<td>' . ( $is_var ? '<span class="description">' . esc_html__( 'set on parent', 'leymish-ai-shopping-readiness-pro' ) . '</span>' : '<input type="text" name="lasr[' . esc_attr( (string) $id ) . '][brand]" value="' . esc_attr( LASR_Audit::brand( $p ) ) . '" />' ) . '</td>';
			echo '<td><input type="text" name="lasr[' . esc_attr( (string) $id ) . '][mpn]" value="' . esc_attr( LASR_Audit::mpn( $p ) ) . '" /></td></tr>';
		}
		echo '</tbody></table>';
		submit_button( __( 'Save all rows on this page', 'leymish-ai-shopping-readiness-pro' ) );
		echo '</form>';

		$pages = (int) ceil( $total / self::PER_PAGE );
		if ( $pages > 1 ) {
			echo '<p>';
			for ( $i = 1; $i <= $pages; $i++ ) {
				$url = admin_url( 'admin.php?page=' . self::SLUG . '&paged=' . $i . ( $all ? '&all=1' : '' ) );
				echo $i === $paged ? '<strong>' . esc_html( (string) $i ) . '</strong> ' : '<a href="' . esc_url( $url ) . '">' . esc_html( (string) $i ) . '</a> ';
			}
			echo '</p>';
		}
		echo '</div>';
	}

	/**
	 * Products and variations to show.
	 *
	 * @param bool $all Include complete products.
	 * @return WC_Product[]
	 */
	private static function items( $all ) {
		$ids   = wc_get_products(
			array(
				'status' => array( 'publish', 'draft', 'private' ),
				'limit'  => -1,
				'return' => 'ids',
				'type'   => array( 'simple', 'variable', 'external' ),
			)
		);
		$items = array();
		foreach ( $ids as $id ) {
			$p = wc_get_product( $id );
			if ( ! $p ) {
				continue;
			}
			$list = array( $p );
			if ( $p->is_type( 'variable' ) ) {
				foreach ( $p->get_children() as $vid ) {
					$v = wc_get_product( $vid );
					if ( $v ) {
						$list[] = $v;
					}
				}
			}
			foreach ( $list as $item ) {
				if ( $all || self::incomplete( $item ) ) {
					$items[] = $item;
				}
			}
		}
		return $items;
	}

	/**
	 * Missing a valid identifier or (for non-variations) a brand.
	 *
	 * @param WC_Product $p Product or variation.
	 * @return bool
	 */
	private static function incomplete( $p ) {
		$gtin = LASR_Audit::gtin( $p );
		$ok   = ( '' !== $gtin && LASR_GTIN::is_valid( $gtin ) ) || '' !== LASR_Audit::mpn( $p );
		if ( ! $p->is_type( 'variation' ) && '' === LASR_Audit::brand( $p ) ) {
			$ok = false;
		}
		return ! $ok;
	}
}
