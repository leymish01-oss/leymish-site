<?php
/**
 * Forget the connection when the plugin is deleted. (Also revoke the key in WooCommerce → Settings → Advanced →
 * REST API; disconnecting first deletes our copy of it.)
 *
 * @package LeyMish_Store_Team
 */

if ( ! defined( 'WP_UNINSTALL_PLUGIN' ) ) {
	exit;
}

delete_option( 'lst_connection' );
