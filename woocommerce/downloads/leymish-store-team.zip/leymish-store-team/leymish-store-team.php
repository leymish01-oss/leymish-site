<?php
/**
 * Plugin Name:          LeyMish Store Team
 * Plugin URI:           https://www.leymish.com/woocommerce/
 * Description:          An AI CEO and a small team of specialist agents that run your store's routine work, within limits you set, asking before anything that matters. Beta: dashboard, approvals and the WooCommerce connection.
 * Version:              0.2.0
 * Requires at least:    6.4
 * Requires PHP:         7.4
 * Requires Plugins:     woocommerce
 * Author:               LeyMish Labs
 * License:              GPL-2.0-or-later
 * Text Domain:          leymish-store-team
 *
 * @package LeyMish_Store_Team
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

define( 'LST_VERSION', '0.2.0' );
define( 'LST_FILE', __FILE__ );
define( 'LST_API', 'https://leymish-ai.leymish.workers.dev/v1/team' );

/**
 * The dashboard page, the connection and approvals (all proxied server-side to the LeyMish Worker).
 */
class LST_Admin {

	const SLUG   = 'leymish-store-team';
	const OPTION = 'lst_connection'; // store_id, site_token, plan

	/**
	 * Hooks.
	 */
	public static function init() {
		add_action( 'admin_menu', array( __CLASS__, 'menu' ), 61 );
		add_action( 'admin_enqueue_scripts', array( __CLASS__, 'assets' ) );
		add_action( 'admin_post_lst_connect', array( __CLASS__, 'handle_connect' ) );
		add_action( 'admin_post_lst_disconnect', array( __CLASS__, 'handle_disconnect' ) );
		add_action( 'admin_post_lst_beta', array( __CLASS__, 'handle_beta' ) );
		add_action( 'wp_ajax_lst_decide', array( __CLASS__, 'ajax_decide' ) );
		add_action( 'wp_ajax_lst_revert', array( __CLASS__, 'ajax_revert' ) );
	}

	/**
	 * WooCommerce → Store Team.
	 */
	public static function menu() {
		add_submenu_page( 'woocommerce', __( 'Store Team', 'leymish-store-team' ), __( 'Store Team', 'leymish-store-team' ), 'manage_woocommerce', self::SLUG, array( __CLASS__, 'render' ) );
	}

	/**
	 * CSS and JS on our page only.
	 *
	 * @param string $hook Page hook.
	 */
	public static function assets( $hook ) {
		if ( false === strpos( (string) $hook, self::SLUG ) ) {
			return;
		}
		wp_enqueue_style( 'lst-admin', plugins_url( 'assets/team.css', LST_FILE ), array(), LST_VERSION );
		wp_enqueue_script( 'lst-admin', plugins_url( 'assets/team.js', LST_FILE ), array(), LST_VERSION, true );
	}

	/**
	 * Saved connection, or null.
	 *
	 * @return array|null
	 */
	public static function connection() {
		$c = get_option( self::OPTION );
		return is_array( $c ) && ! empty( $c['site_token'] ) ? $c : null;
	}

	/**
	 * POST to the Worker.
	 *
	 * @param string $path  Path under /v1/team/.
	 * @param array  $body  JSON body.
	 * @param string $token Site token.
	 * @return array{status:int,data:array}
	 */
	private static function api( $path, array $body = array(), $token = '' ) {
		$args = array(
			'timeout' => 15,
			'headers' => array( 'Content-Type' => 'application/json' ),
			'body'    => wp_json_encode( $body ),
		);
		if ( $token ) {
			$args['headers']['Authorization'] = 'Bearer ' . $token;
		}
		$r = wp_remote_post( LST_API . '/' . $path, $args );
		if ( is_wp_error( $r ) ) {
			return array( 'status' => 0, 'data' => array() );
		}
		$data = json_decode( wp_remote_retrieve_body( $r ), true );
		return array( 'status' => (int) wp_remote_retrieve_response_code( $r ), 'data' => is_array( $data ) ? $data : array() );
	}

	/**
	 * Dashboard data and where it came from: this store, the mishbio.us demo, or the bundled sample.
	 *
	 * @return array{source:string,data:array}
	 */
	public static function data() {
		$c = self::connection();
		if ( $c ) {
			$r = self::api( 'dashboard', array(), $c['site_token'] );
			if ( 200 === $r['status'] ) {
				return array( 'source' => 'store', 'data' => $r['data'] );
			}
		}
		$r = wp_remote_get( LST_API . '/demo', array( 'timeout' => 10 ) );
		if ( ! is_wp_error( $r ) && 200 === (int) wp_remote_retrieve_response_code( $r ) ) {
			$data = json_decode( wp_remote_retrieve_body( $r ), true );
			if ( is_array( $data ) ) {
				return array( 'source' => 'demo', 'data' => $data );
			}
		}
		$mock = json_decode( (string) file_get_contents( plugin_dir_path( LST_FILE ) . 'assets/mock.json' ), true ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents -- local file.
		return array( 'source' => 'sample', 'data' => is_array( $mock ) ? $mock : array() );
	}

	/**
	 * Start WooCommerce's key flow: the owner approves on their own store, WooCommerce sends the keys to us.
	 */
	public static function handle_connect() {
		if ( ! current_user_can( 'manage_woocommerce' ) ) {
			wp_die( esc_html__( 'You do not have permission to do that.', 'leymish-store-team' ) );
		}
		check_admin_referer( 'lst_connect' );
		if ( 0 !== strpos( home_url(), 'https://' ) ) {
			wp_safe_redirect( admin_url( 'admin.php?page=' . self::SLUG . '&lst_msg=https' ) );
			exit;
		}
		$r = self::api( 'connect/start', array( 'store_url' => home_url( '/' ), 'plan' => 'free', 'return_url' => admin_url( 'admin.php?page=' . self::SLUG ) ) );
		if ( 200 !== $r['status'] || empty( $r['data']['authorize_url'] ) ) {
			wp_safe_redirect( admin_url( 'admin.php?page=' . self::SLUG . '&lst_msg=failed' ) );
			exit;
		}
		update_option( self::OPTION, array( 'store_id' => $r['data']['store_id'], 'site_token' => $r['data']['site_token'] ), false );
		wp_redirect( esc_url_raw( $r['data']['authorize_url'] ) ); // phpcs:ignore WordPress.Security.SafeRedirect.wp_redirect_wp_redirect -- this store's own /wc-auth page.
		exit;
	}

	/**
	 * Disconnect: the Worker deletes its copy of the keys; we forget the site token.
	 */
	public static function handle_disconnect() {
		if ( ! current_user_can( 'manage_woocommerce' ) ) {
			wp_die( esc_html__( 'You do not have permission to do that.', 'leymish-store-team' ) );
		}
		check_admin_referer( 'lst_disconnect' );
		$c = self::connection();
		if ( $c ) {
			self::api( 'disconnect', array(), $c['site_token'] );
		}
		delete_option( self::OPTION );
		wp_safe_redirect( admin_url( 'admin.php?page=' . self::SLUG . '&lst_msg=disconnected' ) );
		exit;
	}

	/**
	 * Claim a founding beta spot (connected stores): free for 30 days, then $49/month only if the owner chooses.
	 */
	public static function handle_beta() {
		if ( ! current_user_can( 'manage_woocommerce' ) ) {
			wp_die( esc_html__( 'You do not have permission to do that.', 'leymish-store-team' ) );
		}
		check_admin_referer( 'lst_beta' );
		$c   = self::connection();
		$msg = 'beta_failed';
		if ( $c ) {
			$r   = self::api( 'beta/claim', array(), $c['site_token'] );
			$msg = 200 === $r['status'] ? 'beta_ok' : ( 409 === $r['status'] ? 'beta_full' : 'beta_failed' );
		}
		wp_safe_redirect( admin_url( 'admin.php?page=' . self::SLUG . '&lst_msg=' . $msg ) );
		exit;
	}

	/**
	 * Founding spots left (live count from the LeyMish service), or null.
	 *
	 * @return int|null
	 */
	private static function beta_left() {
		$r = wp_remote_get( LST_API . '/beta', array( 'timeout' => 8 ) );
		if ( is_wp_error( $r ) || 200 !== (int) wp_remote_retrieve_response_code( $r ) ) {
			return null;
		}
		$d = json_decode( wp_remote_retrieve_body( $r ), true );
		return isset( $d['left'] ) ? (int) $d['left'] : null;
	}

	/**
	 * Approve or reject one proposal (connected stores only).
	 */
	public static function ajax_decide() {
		check_ajax_referer( 'lst_decide' );
		if ( ! current_user_can( 'manage_woocommerce' ) ) {
			wp_send_json_error( array( 'message' => 'forbidden' ), 403 );
		}
		$c = self::connection();
		if ( ! $c ) {
			wp_send_json_error( array( 'message' => __( 'Connect your store first: this is demo data.', 'leymish-store-team' ) ), 400 );
		}
		$id       = isset( $_POST['id'] ) ? absint( $_POST['id'] ) : 0;
		$decision = isset( $_POST['decision'] ) && 'approve' === sanitize_key( wp_unslash( $_POST['decision'] ) ) ? 'approve' : 'reject';
		$r        = self::api( 'approvals/decide', array( 'id' => $id, 'decision' => $decision ), $c['site_token'] );
		200 === $r['status'] ? wp_send_json_success( $r['data'] ) : wp_send_json_error( $r['data'], 400 );
	}

	/**
	 * Undo one change (connected stores only): the Worker writes the old value back.
	 */
	public static function ajax_revert() {
		check_ajax_referer( 'lst_decide' );
		if ( ! current_user_can( 'manage_woocommerce' ) ) {
			wp_send_json_error( array( 'message' => 'forbidden' ), 403 );
		}
		$c = self::connection();
		if ( ! $c ) {
			wp_send_json_error( array( 'message' => __( 'Connect your store first: this is demo data.', 'leymish-store-team' ) ), 400 );
		}
		$r = self::api( 'revert', array( 'id' => isset( $_POST['id'] ) ? absint( $_POST['id'] ) : 0 ), $c['site_token'] );
		200 === $r['status'] ? wp_send_json_success( $r['data'] ) : wp_send_json_error( $r['data'], 400 );
	}

	/**
	 * The page: a shell the script fills from the JSON below.
	 */
	public static function render() {
		if ( ! current_user_can( 'manage_woocommerce' ) ) {
			return;
		}
		$d    = self::data();
		$conn = self::connection();
		echo '<div class="wrap lst-wrap"><h1>' . esc_html__( 'Store Team', 'leymish-store-team' ) . '</h1>';
		$msgs = array(
			'https'        => __( 'Your store needs https to connect.', 'leymish-store-team' ),
			'failed'       => __( 'Couldn\'t start the connection. Try again in a minute.', 'leymish-store-team' ),
			'disconnected' => __( 'Disconnected. Also revoke the key in WooCommerce → Settings → Advanced → REST API.', 'leymish-store-team' ),
			'beta_ok'      => __( 'You have a founding spot: Store Team is free for 30 days. After that it is $49/month only if you choose to continue; nothing is charged automatically.', 'leymish-store-team' ),
			'beta_full'    => __( 'All 5 founding spots are taken. Store Team keeps working on the Free plan.', 'leymish-store-team' ),
			'beta_failed'  => __( 'Could not claim a spot just now. Try again in a minute.', 'leymish-store-team' ),
		);
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- display-only message key from our own redirect.
		$msg = isset( $_GET['lst_msg'] ) ? sanitize_key( wp_unslash( $_GET['lst_msg'] ) ) : '';
		if ( isset( $msgs[ $msg ] ) ) {
			echo '<div class="notice notice-info is-dismissible"><p>' . esc_html( $msgs[ $msg ] ) . '</p></div>';
		}
		$banner = array(
			'store'  => '',
			'demo'   => __( 'Demo: real data from mishbio.us, the store our own agents look after. Connect your store to see yours.', 'leymish-store-team' ),
			'sample' => __( 'Sample data (we couldn\'t reach the LeyMish service). Nothing here is a real store.', 'leymish-store-team' ),
		);
		if ( $banner[ $d['source'] ] ) {
			echo '<div class="lst-banner" role="status"><p>' . esc_html( $banner[ $d['source'] ] ) . '</p>';
			if ( ! $conn ) {
				echo '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '">';
				wp_nonce_field( 'lst_connect' );
				echo '<input type="hidden" name="action" value="lst_connect" />';
				submit_button( __( 'Connect this store (free, read-only)', 'leymish-store-team' ), 'primary', 'submit', false );
				echo ' <span class="description">' . esc_html__( 'WooCommerce asks you to approve. You can disconnect any time.', 'leymish-store-team' ) . '</span></form>';
			}
			echo '</div>';
		}
		echo '<div id="lst-app" data-source="' . esc_attr( $d['source'] ) . '" data-nonce="' . esc_attr( wp_create_nonce( 'lst_decide' ) ) . '" data-ajax="' . esc_url( admin_url( 'admin-ajax.php' ) ) . '"><p>' . esc_html__( 'Loading…', 'leymish-store-team' ) . '</p></div>';
		echo '<script type="application/json" id="lst-data">' . wp_json_encode( $d['data'], JSON_HEX_TAG | JSON_HEX_AMP ) . '</script>';
		if ( $conn && 'store' === $d['source'] && isset( $d['data']['store']['plan'] ) && 'free' === $d['data']['store']['plan'] ) {
			$left = self::beta_left();
			if ( $left ) {
				echo '<div class="lst-banner lst-beta"><p><strong>' . esc_html__( 'Founding beta', 'leymish-store-team' ) . '</strong> ';
				/* translators: %d: founding spots left out of 5. */
				echo esc_html( sprintf( _n( 'Store Team is free for 30 days for 5 founding stores, then $49/month only if you choose to continue. No card now. %d of 5 spots left.', 'Store Team is free for 30 days for 5 founding stores, then $49/month only if you choose to continue. No card now. %d of 5 spots left.', $left, 'leymish-store-team' ), $left ) ) . '</p>';
				echo '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '">';
				wp_nonce_field( 'lst_beta' );
				echo '<input type="hidden" name="action" value="lst_beta" />';
				submit_button( __( 'Join the founding beta', 'leymish-store-team' ), 'primary', 'submit', false );
				echo '</form></div>';
			}
		}
		if ( $conn ) {
			echo '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '" class="lst-disconnect">';
			wp_nonce_field( 'lst_disconnect' );
			echo '<input type="hidden" name="action" value="lst_disconnect" />';
			submit_button( __( 'Disconnect this store', 'leymish-store-team' ), 'secondary', 'submit', false );
			echo '</form>';
		}
		echo '</div>';
	}
}

add_action(
	'plugins_loaded',
	function () {
		if ( class_exists( 'WooCommerce' ) && is_admin() ) {
			LST_Admin::init();
		}
	}
);
