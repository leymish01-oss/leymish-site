<?php
/**
 * Plugin Name:          LeyMish AI Readiness Pro (now built in)
 * Plugin URI:           https://www.leymish.com/woocommerce/
 * Description:          Pro is now built into LeyMish AI Readiness 2.0. Update LeyMish AI Readiness from WordPress.org; your licence, settings, feeds and history move over by themselves, and this plugin is switched off. Then you can delete it.
 * Version:              2.0.0
 * Requires at least:    6.4
 * Requires PHP:         7.4
 * Author:               LeyMish Labs
 * Author URI:           https://www.leymish.com/
 * License:              GPL-2.0-or-later
 * License URI:          https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain:          leymish-ai-shopping-readiness-pro
 *
 * @package LeyMish_AI_Shopping_Readiness_Pro
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// The final version: it only says where Pro went. It stores nothing and deletes nothing, so removing it is safe.
add_action(
	'admin_notices',
	function () {
		if ( ! current_user_can( 'activate_plugins' ) ) {
			return;
		}
		$screen = function_exists( 'get_current_screen' ) ? get_current_screen() : null;
		if ( ! $screen || ! in_array( $screen->id, array( 'plugins', 'dashboard' ), true ) ) {
			return;
		}
		$url = current_user_can( 'install_plugins' ) ? admin_url( 'plugin-install.php?s=leymish+ai+shopping+readiness&tab=search&type=term' ) : admin_url( 'plugins.php' );
		echo '<div class="notice notice-info"><p><strong>' . esc_html__( 'Pro is now built into LeyMish AI Readiness.', 'leymish-ai-shopping-readiness-pro' ) . '</strong> ' . esc_html__( 'Update or install LeyMish AI Readiness 2.0 from WordPress.org: your licence, settings, feeds and history move over by themselves. Then you can delete this plugin.', 'leymish-ai-shopping-readiness-pro' ) . '</p><p><a class="button button-primary" href="' . esc_url( $url ) . '">' . esc_html__( 'Get LeyMish AI Readiness', 'leymish-ai-shopping-readiness-pro' ) . '</a></p></div>';
	}
);
