<?php
/**
 * Plugin Name:          LeyMish AI Shopping Readiness Pro
 * Plugin URI:           https://www.leymish.com/woocommerce/pro.html
 * Description:          Pro add-on for LeyMish AI Shopping Readiness: bulk editor for GTIN, brand and MPN; OpenAI and Google product feeds on your own domain; llms.txt generator; weekly re-audit email; score history. Needs the free plugin and a license key from Gumroad.
 * Version:              1.0.0
 * Requires at least:    6.4
 * Requires PHP:         7.4
 * Requires Plugins:     woocommerce, leymish-ai-shopping-readiness
 * Author:               LeyMish Labs
 * Author URI:           https://www.leymish.com/
 * License:              GPL-2.0-or-later
 * License URI:          https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain:          leymish-ai-shopping-readiness-pro
 * WC requires at least: 8.0
 * WC tested up to:      11.1
 *
 * @package LeyMish_AI_Shopping_Readiness_Pro
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

define( 'LASR_PRO_VERSION', '1.0.0' );
define( 'LASR_PRO_FILE', __FILE__ );
define( 'LASR_PRO_DIR', plugin_dir_path( __FILE__ ) );

require_once LASR_PRO_DIR . 'includes/pro-config.php';
require_once LASR_PRO_DIR . 'includes/class-lasr-pro-license.php';
require_once LASR_PRO_DIR . 'includes/class-lasr-pro-feeds.php';
require_once LASR_PRO_DIR . 'includes/class-lasr-pro-llms.php';
require_once LASR_PRO_DIR . 'includes/class-lasr-pro-schedule.php';

add_action(
	'before_woocommerce_init',
	function () {
		if ( class_exists( '\Automattic\WooCommerce\Utilities\FeaturesUtil' ) ) {
			\Automattic\WooCommerce\Utilities\FeaturesUtil::declare_compatibility( 'custom_order_tables', __FILE__, true );
		}
	}
);

add_action( 'plugins_loaded', 'lasr_pro_boot', 20 );

/**
 * Start once WooCommerce and the free plugin are loaded.
 */
function lasr_pro_boot() {
	if ( ! class_exists( 'WooCommerce' ) || ! class_exists( 'LASR_Audit' ) ) {
		add_action( 'admin_notices', 'lasr_pro_notice_needs_free' );
		return;
	}
	LASR_Pro_License::init();
	LASR_Pro_Feeds::init();
	LASR_Pro_Llms::init();
	LASR_Pro_Schedule::init();
	if ( is_admin() ) {
		require_once LASR_PRO_DIR . 'includes/class-lasr-pro-editor.php';
		require_once LASR_PRO_DIR . 'includes/class-lasr-pro-admin.php';
		LASR_Pro_Admin::init();
		LASR_Pro_Editor::init();
	}
}

/**
 * Shown when the free plugin or WooCommerce is missing.
 */
function lasr_pro_notice_needs_free() {
	if ( ! current_user_can( 'activate_plugins' ) ) {
		return;
	}
	echo '<div class="notice notice-warning"><p>' . esc_html__( 'LeyMish AI Shopping Readiness Pro needs WooCommerce and the free LeyMish AI Shopping Readiness plugin to be active.', 'leymish-ai-shopping-readiness-pro' ) . '</p></div>';
}

register_activation_hook( __FILE__, 'lasr_pro_activate' );
register_deactivation_hook( __FILE__, 'lasr_pro_deactivate' );

/**
 * Add the feed and llms.txt URLs, and schedule the weekly jobs.
 */
function lasr_pro_activate() {
	LASR_Pro_Feeds::rewrite_rules();
	LASR_Pro_Llms::rewrite_rules();
	flush_rewrite_rules();
	LASR_Pro_Schedule::schedule();
}

/**
 * Remove URLs and scheduled jobs.
 */
function lasr_pro_deactivate() {
	flush_rewrite_rules();
	LASR_Pro_Schedule::unschedule();
}
