<?php
/**
 * Build-time settings. build.py writes the Gumroad product ID here from pro-config.json.
 *
 * @package LeyMish_AI_Shopping_Readiness_Pro
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! defined( 'LASR_PRO_GUMROAD_PRODUCT_ID' ) ) {
	define( 'LASR_PRO_GUMROAD_PRODUCT_ID', 'a9h7HfYtbwzQv6xxDhSAdQ==' );
}
