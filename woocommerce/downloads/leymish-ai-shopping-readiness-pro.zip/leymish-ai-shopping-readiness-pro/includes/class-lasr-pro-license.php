<?php
/**
 * Gumroad license: activate, re-check weekly, and gate the Pro features.
 *
 * The only outside request this add-on makes is to Gumroad's license API, with the key and product ID.
 *
 * @package LeyMish_AI_Shopping_Readiness_Pro
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * License state is stored as: key, status (valid|invalid|expired), checked_at, valid_at, message.
 */
class LASR_Pro_License {

	const OPTION   = 'lasr_pro_license';
	const ENDPOINT = 'https://api.gumroad.com/v2/licenses/verify';
	const GRACE    = 1209600; // 14 days.

	/**
	 * Weekly re-check hook.
	 */
	public static function init() {
		add_action( 'lasr_pro_license_recheck', array( __CLASS__, 'recheck' ) );
	}

	/**
	 * Current state.
	 *
	 * @return array
	 */
	public static function state() {
		$s = get_option( self::OPTION );
		return is_array( $s ) ? $s : array(
			'key'        => '',
			'status'     => 'none',
			'checked_at' => 0,
			'valid_at'   => 0,
			'message'    => '',
		);
	}

	/**
	 * Whether Pro features are on: a valid key, or a recent valid check when Gumroad was unreachable.
	 *
	 * @return bool
	 */
	public static function is_active() {
		$s = self::state();
		if ( 'valid' === $s['status'] ) {
			return true;
		}
		return 'unreachable' === $s['status'] && ( time() - (int) $s['valid_at'] ) < self::GRACE;
	}

	/**
	 * Activate a key (counts one use on Gumroad).
	 *
	 * @param string $key License key.
	 * @return array New state.
	 */
	public static function activate( $key ) {
		return self::verify( sanitize_text_field( $key ), true );
	}

	/**
	 * Weekly re-check (doesn't count a use).
	 */
	public static function recheck() {
		$s = self::state();
		if ( '' !== $s['key'] ) {
			self::verify( $s['key'], false );
		}
	}

	/**
	 * Remove the key.
	 */
	public static function deactivate() {
		delete_option( self::OPTION );
	}

	/**
	 * Ask Gumroad whether the key is valid, and save the result.
	 *
	 * @param string $key       License key.
	 * @param bool   $count_use Increment Gumroad's uses count.
	 * @return array New state.
	 */
	private static function verify( $key, $count_use ) {
		$prev  = self::state();
		$state = array(
			'key'        => $key,
			'status'     => 'invalid',
			'checked_at' => time(),
			'valid_at'   => (int) $prev['valid_at'],
			'message'    => '',
		);
		if ( '' === LASR_PRO_GUMROAD_PRODUCT_ID ) {
			$state['message'] = __( 'This build has no Gumroad product ID. Download the latest version from your Gumroad library.', 'leymish-ai-shopping-readiness-pro' );
			update_option( self::OPTION, $state, false );
			return $state;
		}
		$res = wp_remote_post(
			self::ENDPOINT,
			array(
				'timeout' => 15,
				'body'    => array(
					'product_id'           => LASR_PRO_GUMROAD_PRODUCT_ID,
					'license_key'          => $key,
					'increment_uses_count' => $count_use ? 'true' : 'false',
				),
			)
		);
		if ( is_wp_error( $res ) || (int) wp_remote_retrieve_response_code( $res ) >= 500 ) {
			$state['status']  = ( 'valid' === $prev['status'] || 'unreachable' === $prev['status'] ) ? 'unreachable' : 'invalid';
			$state['message'] = __( 'Could not reach Gumroad to check the license. Pro stays on for up to 14 days after the last successful check.', 'leymish-ai-shopping-readiness-pro' );
			update_option( self::OPTION, $state, false );
			return $state;
		}
		$data = json_decode( (string) wp_remote_retrieve_body( $res ), true );
		$eval = self::evaluate( is_array( $data ) ? $data : array() );

		$state['status']  = $eval['status'];
		$state['message'] = $eval['message'];
		if ( 'valid' === $eval['status'] ) {
			$state['valid_at'] = time();
		}
		update_option( self::OPTION, $state, false );
		return $state;
	}

	/**
	 * Decide validity from Gumroad's response. Refunds, chargebacks, disputes and ended or failed
	 * subscriptions make a key invalid (fields are checked only when Gumroad includes them).
	 *
	 * @param array $data Decoded response.
	 * @return array{status:string,message:string}
	 */
	public static function evaluate( array $data ) {
		if ( empty( $data['success'] ) ) {
			return array(
				'status'  => 'invalid',
				'message' => isset( $data['message'] ) ? sanitize_text_field( (string) $data['message'] ) : __( 'Gumroad did not recognise this key.', 'leymish-ai-shopping-readiness-pro' ),
			);
		}
		$p = isset( $data['purchase'] ) && is_array( $data['purchase'] ) ? $data['purchase'] : array();
		foreach ( array( 'refunded', 'chargebacked', 'disputed' ) as $flag ) {
			if ( ! empty( $p[ $flag ] ) ) {
				return array(
					'status'  => 'invalid',
					/* translators: %s: refunded, chargebacked or disputed. */
					'message' => sprintf( __( 'This purchase was %s.', 'leymish-ai-shopping-readiness-pro' ), $flag ),
				);
			}
		}
		foreach ( array( 'subscription_ended_at', 'subscription_cancelled_at', 'subscription_failed_at' ) as $field ) {
			if ( ! empty( $p[ $field ] ) && strtotime( (string) $p[ $field ] ) <= time() ) {
				return array(
					'status'  => 'expired',
					'message' => __( 'This license is no longer active on Gumroad. Check your purchase there, or contact us from your receipt.', 'leymish-ai-shopping-readiness-pro' ),
				);
			}
		}
		return array(
			'status'  => 'valid',
			'message' => __( 'License active.', 'leymish-ai-shopping-readiness-pro' ),
		);
	}
}
