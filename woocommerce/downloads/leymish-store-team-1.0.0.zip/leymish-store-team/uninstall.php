<?php
/**
 * Deleting this final version removes nothing: LeyMish AI Readiness 2.0 keeps its own copies of the licence,
 * settings, connection and feeds. (This file exists so WordPress finds an uninstaller that does nothing.)
 *
 * @package LeyMish_AI_Readiness_Stub
 */

if ( ! defined( 'WP_UNINSTALL_PLUGIN' ) ) {
	exit;
}
