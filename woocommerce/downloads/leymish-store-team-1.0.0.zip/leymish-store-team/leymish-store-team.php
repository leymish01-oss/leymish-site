<?php
/**
 * Plugin Name:          LeyMish Store Team (now built in)
 * Plugin URI:           https://www.leymish.com/woocommerce/
 * Description:          Store Team is now built into LeyMish AI Readiness 2.0 (the Team tab). Update or install LeyMish AI Readiness from WordPress.org; your Store Team connection moves over by itself, and this plugin is switched off. Then you can delete it.
 * Version:              1.0.0
 * Requires at least:    6.4
 * Requires PHP:         7.4
 * Author:               LeyMish Labs
 * License:              GPL-2.0-or-later
 * Text Domain:          leymish-store-team
 *
 * @package LeyMish_Store_Team
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// The final version: it only says where Store Team went. It stores nothing and deletes nothing.
add_action(
	'admin_notices',
	function () {
		if ( ! current_user_can( 'activate_plugins' ) ) {
			return;
		}
		$screen = function_exists( 'get_current_screen' ) ? get_current_screen() : null;
		if ( ! $screen || ! in_array( $screen->id, array( 'plugins', 'dashboard' ), true ) ) {
			return;
		}
		$url = current_user_can( 'install_plugins' ) ? admin_url( 'plugin-install.php?s=leymish+ai+shopping+readiness&tab=search&type=term' ) : admin_url( 'plugins.php' );
		echo '<div class="notice notice-info"><p><strong>' . esc_html__( 'Store Team is now built into LeyMish AI Readiness.', 'leymish-store-team' ) . '</strong> ' . esc_html__( 'Update or install LeyMish AI Readiness 2.0 from WordPress.org and open its Team tab: your connection moves over by itself. Then you can delete this plugin.', 'leymish-store-team' ) . '</p><p><a class="button button-primary" href="' . esc_url( $url ) . '">' . esc_html__( 'Get LeyMish AI Readiness', 'leymish-store-team' ) . '</a></p></div>';
	}
);
