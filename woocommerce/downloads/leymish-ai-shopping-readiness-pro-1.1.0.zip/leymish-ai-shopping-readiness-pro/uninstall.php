<?php
/**
 * Remove Pro settings, history and cached feeds when the add-on is deleted.
 *
 * @package LeyMish_AI_Shopping_Readiness_Pro
 */

if ( ! defined( 'WP_UNINSTALL_PLUGIN' ) ) {
	exit;
}

foreach ( array( 'lasr_pro_license', 'lasr_pro_history', 'lasr_pro_llms_enabled', 'lasr_pro_weekly_email', 'lasr_pro_feeds_built' ) as $lasr_option ) {
	delete_option( $lasr_option );
}
$lasr_uploads = wp_upload_dir();
$lasr_dir     = trailingslashit( $lasr_uploads['basedir'] ) . 'lasr-feeds/';
foreach ( array( 'openai.jsonl', 'google.tsv' ) as $lasr_file ) {
	if ( file_exists( $lasr_dir . $lasr_file ) ) {
		wp_delete_file( $lasr_dir . $lasr_file );
	}
}
