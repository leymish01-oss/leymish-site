<?php
/**
 * Gumroad license: activate, re-check weekly, and gate the Pro features.
 *
 * The only outside request this add-on makes is to Gumroad's license API, with the key and product ID.
 *
 * @package LeyMish_AI_Shopping_Readiness_Pro
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * License state is stored as: key, status (valid|invalid|expired), checked_at, valid_at, message.
 */
class LASR_Pro_License {

	const OPTION   = 'lasr_pro_license';
	const ENDPOINT = 'https://api.gumroad.com/v2/licenses/verify';
	const GRACE    = 1209600; // 14 days.

	const AGENCY_SEATS = 10;

	/**
	 * Weekly re-check hook.
	 */
	public static function init() {
		add_action( 'lasr_pro_license_recheck', array( __CLASS__, 'recheck' ) );
	}

	/**
	 * Current state.
	 *
	 * @return array
	 */
	public static function state() {
		$s = get_option( self::OPTION );
		return is_array( $s ) ? $s : array(
			'key'        => '',
			'status'     => 'none',
			'checked_at' => 0,
			'valid_at'   => 0,
			'message'    => '',
		);
	}

	/**
	 * Whether Pro features are on: a valid key, or a recent valid check when Gumroad was unreachable.
	 *
	 * @return bool
	 */
	public static function is_active() {
		$s = self::state();
		if ( 'valid' === $s['status'] ) {
			return true;
		}
		return 'unreachable' === $s['status'] && ( time() - (int) $s['valid_at'] ) < self::GRACE;
	}

	/**
	 * Activate a key (counts one use on Gumroad).
	 *
	 * @param string $key License key.
	 * @return array New state.
	 */
	public static function activate( $key ) {
		return self::verify( sanitize_text_field( $key ), true );
	}

	/**
	 * Weekly re-check (doesn't count a use).
	 */
	public static function recheck() {
		$s = self::state();
		if ( '' !== $s['key'] ) {
			self::verify( $s['key'], false );
		}
	}

	/**
	 * Remove the key.
	 */
	public static function deactivate() {
		delete_option( self::OPTION );
	}

	/**
	 * Ask Gumroad whether the key is valid, and save the result.
	 *
	 * @param string $key       License key.
	 * @param bool   $count_use Increment Gumroad's uses count.
	 * @return array New state.
	 */
	private static function verify( $key, $count_use ) {
		$prev  = self::state();
		$state = array(
			'key'        => $key,
			'status'     => 'invalid',
			'checked_at' => time(),
			'valid_at'   => (int) $prev['valid_at'],
			'message'    => '',
		);
		if ( '' === LASR_PRO_GUMROAD_PRODUCT_ID ) {
			$state['message'] = __( 'This build has no Gumroad product ID. Download the latest version from your Gumroad library.', 'leymish-ai-shopping-readiness-pro' );
			update_option( self::OPTION, $state, false );
			return $state;
		}
		// Store licence first, then the agency licence (10 stores) if that product exists. A key belongs to one
		// product, so Gumroad answers "does not exist" for the other.
		$products = array( array( LASR_PRO_GUMROAD_PRODUCT_ID, 1 ) );
		if ( defined( 'LASR_PRO_GUMROAD_AGENCY_PRODUCT_ID' ) && '' !== LASR_PRO_GUMROAD_AGENCY_PRODUCT_ID ) {
			$products[] = array( LASR_PRO_GUMROAD_AGENCY_PRODUCT_ID, self::AGENCY_SEATS );
		}
		$data  = array();
		$seats = 1;
		foreach ( $products as $product ) {
			$res = wp_remote_post(
				self::ENDPOINT,
				array(
					'timeout' => 15,
					'body'    => array(
						'product_id'           => $product[0],
						'license_key'          => $key,
						'increment_uses_count' => $count_use ? 'true' : 'false',
					),
				)
			);
			if ( is_wp_error( $res ) || (int) wp_remote_retrieve_response_code( $res ) >= 500 ) {
				$state['status']  = ( 'valid' === $prev['status'] || 'unreachable' === $prev['status'] ) ? 'unreachable' : 'invalid';
				$state['message'] = __( 'Could not reach Gumroad to check the license. Pro stays on for up to 14 days after the last successful check.', 'leymish-ai-shopping-readiness-pro' );
				update_option( self::OPTION, $state, false );
				return $state;
			}
			$data  = json_decode( (string) wp_remote_retrieve_body( $res ), true );
			$data  = is_array( $data ) ? $data : array();
			$seats = $product[1];
			if ( ! empty( $data['success'] ) ) {
				break;
			}
		}
		$state['seats'] = $seats;
		$eval           = self::evaluate( $data, $seats );

		$state['status']  = $eval['status'];
		$state['message'] = $eval['message'];
		if ( 'valid' === $eval['status'] ) {
			$state['valid_at'] = time();
		}
		update_option( self::OPTION, $state, false );
		return $state;
	}

	/**
	 * Decide validity from Gumroad's response. Refunds, chargebacks, disputes and ended or failed
	 * subscriptions make a key invalid (fields are checked only when Gumroad includes them).
	 *
	 * A licence covers $seats stores (1, or 10 for the agency licence). Gumroad counts every activation, including
	 * reinstalls on the same store, so activations are allowed up to twice the seats plus one before a key is
	 * refused.
	 *
	 * @param array $data  Decoded response.
	 * @param int   $seats Stores the licence covers.
	 * @return array{status:string,message:string}
	 */
	public static function evaluate( array $data, $seats = 1 ) {
		if ( empty( $data['success'] ) ) {
			return array(
				'status'  => 'invalid',
				'message' => isset( $data['message'] ) ? sanitize_text_field( (string) $data['message'] ) : __( 'Gumroad did not recognise this key.', 'leymish-ai-shopping-readiness-pro' ),
			);
		}
		$p = isset( $data['purchase'] ) && is_array( $data['purchase'] ) ? $data['purchase'] : array();
		foreach ( array( 'refunded', 'chargebacked', 'disputed' ) as $flag ) {
			if ( ! empty( $p[ $flag ] ) ) {
				return array(
					'status'  => 'invalid',
					/* translators: %s: refunded, chargebacked or disputed. */
					'message' => sprintf( __( 'This purchase was %s.', 'leymish-ai-shopping-readiness-pro' ), $flag ),
				);
			}
		}
		foreach ( array( 'subscription_ended_at', 'subscription_cancelled_at', 'subscription_failed_at' ) as $field ) {
			if ( ! empty( $p[ $field ] ) && strtotime( (string) $p[ $field ] ) <= time() ) {
				return array(
					'status'  => 'expired',
					'message' => __( 'This license is no longer active on Gumroad. Check your purchase there, or contact us from your receipt.', 'leymish-ai-shopping-readiness-pro' ),
				);
			}
		}
		$uses  = isset( $data['uses'] ) ? (int) $data['uses'] : 0;
		$limit = 2 * max( 1, (int) $seats ) + 1;
		if ( $uses > $limit ) {
			return array(
				'status'  => 'invalid',
				/* translators: 1: number of activations, 2: number of stores the licence covers. */
				'message' => sprintf( __( 'This license has been activated %1$d times, more than it allows for %2$d store(s). Reply to your Gumroad receipt and we will sort it out.', 'leymish-ai-shopping-readiness-pro' ), $uses, (int) $seats ),
			);
		}
		return array(
			'status'  => 'valid',
			'message' => 1 < (int) $seats
				/* translators: %d: number of stores the agency licence covers. */
				? sprintf( __( 'Agency license active (up to %d stores).', 'leymish-ai-shopping-readiness-pro' ), (int) $seats )
				: __( 'License active.', 'leymish-ai-shopping-readiness-pro' ),
		);
	}
}
