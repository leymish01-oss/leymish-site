<?php
/**
 * WooCommerce → AI Readiness Pro: license, feeds, llms.txt, weekly email, score history.
 *
 * @package LeyMish_AI_Shopping_Readiness_Pro
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Settings page and its form handlers.
 */
class LASR_Pro_Admin {

	const SLUG = 'lasr-ai-readiness-pro';

	/**
	 * Hooks.
	 */
	public static function init() {
		add_action( 'admin_menu', array( __CLASS__, 'menu' ), 61 );
		add_action( 'admin_post_lasr_pro_license', array( __CLASS__, 'handle_license' ) );
		add_action( 'admin_post_lasr_pro_settings', array( __CLASS__, 'handle_settings' ) );
		add_action( 'admin_post_lasr_pro_rebuild', array( __CLASS__, 'handle_rebuild' ) );
	}

	/**
	 * Submenu under WooCommerce.
	 */
	public static function menu() {
		add_submenu_page(
			'woocommerce',
			__( 'AI Readiness Pro', 'leymish-ai-shopping-readiness-pro' ),
			__( 'AI Readiness Pro', 'leymish-ai-shopping-readiness-pro' ),
			'manage_woocommerce',
			self::SLUG,
			array( __CLASS__, 'render' )
		);
	}

	/**
	 * Common guard for form handlers.
	 *
	 * @param string $action Nonce action.
	 */
	private static function guard( $action ) {
		if ( ! current_user_can( 'manage_woocommerce' ) ) {
			wp_die( esc_html__( 'You do not have permission to do that.', 'leymish-ai-shopping-readiness-pro' ) );
		}
		check_admin_referer( $action );
	}

	/**
	 * Back to the page with a message code.
	 *
	 * @param string $msg Message code.
	 */
	private static function back( $msg ) {
		wp_safe_redirect( admin_url( 'admin.php?page=' . self::SLUG . '&lasr_msg=' . rawurlencode( $msg ) ) );
		exit;
	}

	/**
	 * Activate or remove the license key.
	 */
	public static function handle_license() {
		self::guard( 'lasr_pro_license' );
		if ( isset( $_POST['remove'] ) ) {
			LASR_Pro_License::deactivate();
			self::back( 'removed' );
		}
		$key   = isset( $_POST['license_key'] ) ? sanitize_text_field( wp_unslash( $_POST['license_key'] ) ) : '';
		$state = LASR_Pro_License::activate( $key );
		if ( 'valid' === $state['status'] ) {
			LASR_Pro_Feeds::rebuild();
		}
		self::back( $state['status'] );
	}

	/**
	 * Save the llms.txt and weekly email switches.
	 */
	public static function handle_settings() {
		self::guard( 'lasr_pro_settings' );
		update_option( LASR_Pro_Llms::OPTION, isset( $_POST['llms'] ) ? 'yes' : 'no', false );
		update_option( LASR_Pro_Schedule::EMAIL_OPT, isset( $_POST['weekly_email'] ) ? 'yes' : 'no', false );
		self::back( 'saved' );
	}

	/**
	 * Rebuild the feeds now.
	 */
	public static function handle_rebuild() {
		self::guard( 'lasr_pro_rebuild' );
		LASR_Pro_Feeds::rebuild();
		self::back( 'rebuilt' );
	}

	/**
	 * Hidden fields for a form.
	 *
	 * @param string $action admin-post action and nonce action.
	 */
	private static function form_fields( $action ) {
		wp_nonce_field( $action );
		echo '<input type="hidden" name="action" value="' . esc_attr( $action ) . '" />';
	}

	/**
	 * The page.
	 */
	public static function render() {
		if ( ! current_user_can( 'manage_woocommerce' ) ) {
			return;
		}
		$state  = LASR_Pro_License::state();
		$active = LASR_Pro_License::is_active();
		$post   = esc_url( admin_url( 'admin-post.php' ) );
		echo '<div class="wrap"><h1>' . esc_html__( 'AI Readiness Pro', 'leymish-ai-shopping-readiness-pro' ) . '</h1>';

		// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- display-only message code after our own redirect.
		$msg = isset( $_GET['lasr_msg'] ) ? sanitize_key( wp_unslash( $_GET['lasr_msg'] ) ) : '';
		if ( $msg ) {
			$ok = in_array( $msg, array( 'valid', 'saved', 'rebuilt', 'removed' ), true );
			echo '<div class="notice ' . ( $ok ? 'notice-success' : 'notice-error' ) . ' is-dismissible"><p>' . esc_html( $state['message'] ? $state['message'] : ucfirst( $msg ) ) . '</p></div>';
		}

		echo '<h2>' . esc_html__( 'License', 'leymish-ai-shopping-readiness-pro' ) . '</h2>';
		echo '<form method="post" action="' . $post . '">'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- escaped above with esc_url().
		self::form_fields( 'lasr_pro_license' );
		if ( $active ) {
			$masked = str_repeat( '•', max( 0, strlen( $state['key'] ) - 4 ) ) . substr( $state['key'], -4 );
			/* translators: %s: masked license key. */
			echo '<p>' . esc_html( sprintf( __( 'Active: %s', 'leymish-ai-shopping-readiness-pro' ), $masked ) ) . '</p>';
			submit_button( __( 'Remove license from this site', 'leymish-ai-shopping-readiness-pro' ), 'secondary', 'remove', false );
		} else {
			echo '<p><input type="text" name="license_key" class="regular-text" autocomplete="off" placeholder="XXXXXXXX-XXXXXXXX-XXXXXXXX-XXXXXXXX" /> ';
			submit_button( __( 'Activate', 'leymish-ai-shopping-readiness-pro' ), 'primary', 'submit', false );
			echo '</p><p class="description">' . esc_html__( 'Your key is in the Gumroad receipt email. Activating sends only the key and the product ID to Gumroad to check it; nothing else leaves your site.', 'leymish-ai-shopping-readiness-pro' ) . '</p>';
		}
		echo '</form>';

		if ( ! $active ) {
			echo '</div>';
			return;
		}

		$built = get_option( 'lasr_pro_feeds_built' );
		echo '<h2>' . esc_html__( 'Product feeds', 'leymish-ai-shopping-readiness-pro' ) . '</h2>';
		echo '<p>' . esc_html__( 'Stable URLs to give to OpenAI (ChatGPT merchant onboarding) and Google Merchant Center (scheduled fetch). They rebuild a minute after you save a product.', 'leymish-ai-shopping-readiness-pro' ) . '</p><ul>';
		foreach ( array( 'openai.jsonl' => 'OpenAI (JSONL)', 'google.tsv' => 'Google Merchant Center (TSV)' ) as $file => $label ) {
			$url = LASR_Pro_Feeds::url( $file );
			echo '<li><strong>' . esc_html( $label ) . ':</strong> <a href="' . esc_url( $url ) . '" target="_blank" rel="noopener">' . esc_html( $url ) . '</a></li>';
		}
		echo '</ul>';
		if ( is_array( $built ) ) {
			/* translators: 1: number of items, 2: date and time. */
			echo '<p class="description">' . esc_html( sprintf( __( '%1$d items, last built %2$s.', 'leymish-ai-shopping-readiness-pro' ), (int) $built['rows'], wp_date( get_option( 'date_format' ) . ' ' . get_option( 'time_format' ), (int) $built['at'] ) ) ) . '</p>';
		}
		echo '<form method="post" action="' . $post . '">'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- escaped above with esc_url().
		self::form_fields( 'lasr_pro_rebuild' );
		submit_button( __( 'Rebuild feeds now', 'leymish-ai-shopping-readiness-pro' ), 'secondary', 'submit', false );
		echo '</form>';

		echo '<h2>' . esc_html__( 'Settings', 'leymish-ai-shopping-readiness-pro' ) . '</h2>';
		echo '<form method="post" action="' . $post . '">'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- escaped above with esc_url().
		self::form_fields( 'lasr_pro_settings' );
		echo '<p><label><input type="checkbox" name="llms" value="1" ' . checked( 'yes', get_option( LASR_Pro_Llms::OPTION, 'no' ), false ) . ' /> ' . esc_html__( 'Serve a generated /llms.txt (store summary, categories, policies and feed links). A real llms.txt file on your server always takes priority.', 'leymish-ai-shopping-readiness-pro' ) . '</label></p>';
		echo '<p><label><input type="checkbox" name="weekly_email" value="1" ' . checked( 'yes', get_option( LASR_Pro_Schedule::EMAIL_OPT, 'yes' ), false ) . ' /> ' . esc_html__( 'Re-run the audit weekly and email the score and top fixes to the site admin address.', 'leymish-ai-shopping-readiness-pro' ) . '</label></p>';
		submit_button( __( 'Save settings', 'leymish-ai-shopping-readiness-pro' ) );
		echo '</form>';

		$history = array_reverse( LASR_Pro_Schedule::history() );
		echo '<h2>' . esc_html__( 'Score history', 'leymish-ai-shopping-readiness-pro' ) . '</h2>';
		if ( ! $history ) {
			echo '<p>' . esc_html__( 'Scores are recorded from the next audit.', 'leymish-ai-shopping-readiness-pro' ) . '</p>';
		} else {
			echo '<table class="widefat striped" style="max-width:420px"><thead><tr><th>' . esc_html__( 'Date', 'leymish-ai-shopping-readiness-pro' ) . '</th><th>' . esc_html__( 'Score', 'leymish-ai-shopping-readiness-pro' ) . '</th></tr></thead><tbody>';
			foreach ( array_slice( $history, 0, 26 ) as $h ) {
				echo '<tr><td>' . esc_html( wp_date( get_option( 'date_format' ), (int) $h['t'] ) ) . '</td><td>' . esc_html( (string) (int) $h['s'] ) . '</td></tr>';
			}
			echo '</tbody></table>';
		}
		echo '</div>';
	}
}
